import tensorflow as tf
import numpy as np
from models.shares import Base, fc_layer, flip_gradient, CharTDNNHW, BiRNN, CRF, self_attn, focal_loss, Embedding,save_cr_and_cm
from utils.logger import Progbar
import os
from tensorflow.contrib.layers import flatten


class DATNetFModel(Base):
    """Full Transfer and DATNet-F modules"""
    def __init__(self, config):
        super(DATNetFModel, self).__init__(config)
        self._init_configs()
        with tf.Graph().as_default():
            self._add_placeholders()
            self._build_model()
            self.logger.info("total params: {}".format(self.count_params()))
            self._initialize_session()


    def _init_configs(self):
        s_vocab = self.load_dataset(self.cfg.src_vocab)
        t_vocab = self.load_dataset(self.cfg.tgt_vocab)
        self.sw_dict, self.sl_dict = s_vocab["word_dict"], s_vocab["label_dict"]
        self.tw_dict, self.tl_dict = t_vocab["word_dict"], t_vocab["label_dict"]
        del s_vocab, t_vocab
        self.sw_size,  self.sl_size = len(self.sw_dict),  len(self.sl_dict)
        self.tw_size,  self.tl_size = len(self.tw_dict),  len(self.tl_dict)
        self.rev_sw_dict = dict([(idx, word) for word, idx in self.sw_dict.items()])       
        self.rev_sl_dict = dict([(idx, label) for label, idx in self.sl_dict.items()])
        self.rev_tw_dict = dict([(idx, word) for word, idx in self.tw_dict.items()])       
        self.rev_tl_dict = dict([(idx, label) for label, idx in self.tl_dict.items()])        
        self.wd_param = 0.1
        self.gp_param = 10
        self.D_train_num =10
    def _get_feed_dict(self, src_data, tgt_data, domain_labels, is_train=False, src_lr=None, tgt_lr=None):
        feed_dict = {self.is_train: is_train}
        if src_lr is not None:
            feed_dict[self.src_lr] = src_lr
        if tgt_lr is not None:
            feed_dict[self.tgt_lr] = tgt_lr
        if src_data is not None:
            feed_dict[self.src_words] = src_data["words"]
            feed_dict[self.src_seq_len] = src_data["seq_len"]
            if "labels" in src_data:
                feed_dict[self.src_labels] = src_data["labels"]
        if tgt_data is not None:
            feed_dict[self.tgt_words] = tgt_data["words"]
            feed_dict[self.tgt_seq_len] = tgt_data["seq_len"]
            if "labels" in tgt_data:
                feed_dict[self.tgt_labels] = tgt_data["labels"]
        if domain_labels is not None:
            feed_dict[self.domain_labels] = domain_labels
        return feed_dict

    def _add_placeholders(self):
        # source placeholders

        self.src_words = tf.placeholder(tf.int32, shape=[None, 200], name="source_words")
        self.src_seq_len = tf.placeholder(tf.int32, shape=[None], name="source_seq_len")        
        self.src_labels = tf.placeholder(tf.int32, shape=[None, None], name="source_labels")
        # target placeholders
        self.tgt_words = tf.placeholder(tf.int32, shape=[None, 200], name="target_words")
        self.tgt_seq_len = tf.placeholder(tf.int32, shape=[None], name="target_seq_len")        
        self.tgt_labels = tf.placeholder(tf.int32, shape=[None, None], name="target_labels")
        # domain labels
        self.domain_labels = tf.placeholder(tf.int32, shape=[None, 2], name="domain_labels")
        # hyper-parameters
        self.is_train = tf.placeholder(tf.bool, shape=[], name="is_train")
        self.src_lr = tf.placeholder(tf.float32, name="source_learning_rate")
        self.tgt_lr = tf.placeholder(tf.float32, name="target_learning_rate")
        self.loss_summary = tf.Variable(0.0, dtype=tf.float32,trainable=False)
        self.mean_loss_summary = tf.Variable(0.0,dtype=tf.float32, trainable=False)
        self.test_f1 = tf.Variable(0.0,dtype=tf.float32, trainable=False)
        self.dev_f1 = tf.Variable(0.0,dtype=tf.float32, trainable=False)
        self.max_seq_len = self.cfg.max_seq_len


    def _tensorboard(self):
        tf.summary.scalar('loss/negative_wgan_d_loss', -self.wgan_d_loss)
        tf.summary.scalar('loss/gp_loss', self.gp_loss)
        tf.summary.scalar('loss/negative_src_loss', -self.src_loss)  # negative critic loss
        tf.summary.scalar('loss/tgt_loss', self.tgt_loss)

        self.summary_op = tf.summary.merge_all()


    def _build_model(self):
        with tf.variable_scope("embeddings_op"):
            # word table
            if self.cfg.share_word:
                word_table = Embedding(self.sw_size, self.cfg.src_word_dim, self.cfg.src_wordvec,
                                       self.cfg.src_word_weight, self.cfg.tune_emb, self.cfg.at, self.cfg.norm_emb,
                                       self.cfg.word_project, scope="word_table")
                src_word_emb = word_table(self.src_words)
                tgt_word_emb = word_table(self.tgt_words)
            else:
                src_word_table = Embedding(self.sw_size, self.cfg.src_word_dim, self.cfg.src_wordvec,
                                           self.cfg.src_word_weight, self.cfg.tune_emb, self.cfg.at, self.cfg.norm_emb,
                                           self.cfg.word_project, scope="source_word_table")
                src_word_emb = src_word_table(self.src_words)
                tgt_word_table = Embedding(self.tw_size, self.cfg.tgt_word_dim, self.cfg.tgt_wordvec,
                                           self.cfg.tgt_word_weight, self.cfg.tune_emb, self.cfg.at, self.cfg.norm_emb,
                                           self.cfg.word_project, scope="target_word_table")
                tgt_word_emb = tgt_word_table(self.tgt_words)
            # char table (default char is shared)

        with tf.variable_scope("computation_graph"):
            # build module
            emb_dropout = tf.layers.Dropout(rate=self.cfg.emb_drop_rate)
            bi_rnn = BiRNN(self.cfg.num_units, drop_rate=self.cfg.rnn_drop_rate, concat=self.cfg.concat_rnn,
                           activation=tf.tanh, reuse=tf.AUTO_REUSE, scope="bi_rnn")
            # create dense layer
            if self.cfg.share_dense:
                src_dense = tf.layers.Dense(self.sl_size, use_bias=True, _reuse=tf.AUTO_REUSE, name="project")
                tgt_dense = tf.layers.Dense(self.tl_size, use_bias=True, _reuse=tf.AUTO_REUSE, name="project")
            else:
                src_dense = tf.layers.Dense(self.sl_size, use_bias=True, _reuse=tf.AUTO_REUSE, name="src_project")
                tgt_dense = tf.layers.Dense(self.tl_size, use_bias=True, _reuse=tf.AUTO_REUSE, name="tgt_project")
            # create CRF layer
            if self.cfg.share_label:
                src_crf_layer = CRF(self.sl_size, reuse=tf.AUTO_REUSE, scope="crf_layer")
                tgt_crf_layer = CRF(self.sl_size, reuse=tf.AUTO_REUSE, scope="crf_layer")
            else:
                src_crf_layer = CRF(self.sl_size, reuse=tf.AUTO_REUSE, scope="src_crf_layer")
                tgt_crf_layer = CRF(self.tl_size, reuse=tf.AUTO_REUSE, scope="tgt_crf_layer")

            # compute outputs
            def discriminator(feature):
                feat = flip_gradient(feature, lw=self.cfg.grad_rev_rate)
                outputs = self_attn(feat, reuse=tf.AUTO_REUSE, name="self_attention")
                logits = tf.layers.dense(outputs, units=2, use_bias=True, name="disc_project", reuse=tf.AUTO_REUSE)
                if self.cfg.discriminator == 2:  # GRAD
                    loss = focal_loss(logits, self.domain_labels, alpha=self.cfg.alpha, gamma=self.cfg.gamma)
                    loss = tf.reduce_mean(loss)
                else:  # normal discriminator
                    loss = tf.nn.softmax_cross_entropy_with_logits_v2(logits=logits, labels=self.domain_labels)
                    loss = tf.reduce_mean(loss)
                return loss

            def fc_layer(input_tensor, input_dim, output_dim, layer_name, act=tf.nn.relu, input_type='dense'):
                with tf.name_scope(layer_name):
                    weight = tf.Variable(tf.truncated_normal([input_dim, output_dim], stddev=1. / tf.sqrt(input_dim / 2.)), name='weight')
                    bias = tf.Variable(tf.constant(0.1, shape=[output_dim]), name='bias')
                    if input_type == 'sparse':
                        activations = act(tf.sparse_tensor_dense_matmul(input_tensor, weight) + bias)
                    else:
                        activations = act(tf.matmul(input_tensor, weight) + bias)
                    return activations
            
            def compute_src_logits(word_emb):
                emb = emb_dropout(word_emb, training=self.is_train)
                rnn_outs = bi_rnn(emb,seq_len=None,training=self.is_train)
                logits = src_dense(rnn_outs)
                transition, mean_loss = src_crf_layer(logits, self.src_labels, self.src_seq_len)
                return rnn_outs, logits, transition, mean_loss

            def compute_tgt_logits(word_emb):
                emb = emb_dropout( word_emb, training=self.is_train)
                rnn_outs = bi_rnn(emb,seq_len=None,training=self.is_train)
                logits = tgt_dense(rnn_outs)
                transition, mean_loss = tgt_crf_layer(logits, self.tgt_labels, self.tgt_seq_len)
                return rnn_outs, logits, transition, mean_loss

            # train source
            with tf.name_scope('generator'):
                src_rnn_outs, self.src_logits, self.src_transition, self.src_loss = compute_src_logits(src_word_emb)
                if self.cfg.at:  # adversarial training
                    perturb_src_word_emb = self.add_perturbation(src_word_emb, self.src_loss, epsilon=self.cfg.epsilon)
                    *_, adv_src_loss = compute_src_logits(perturb_src_word_emb)
                    self.src_loss = self.src_loss + adv_src_loss
                if self.cfg.discriminator != 0:  # if 0 means no discriminator is applied
                    src_dis_loss = discriminator(src_rnn_outs)
                    self.src_loss = self.src_loss + src_dis_loss

                # train target
                tgt_rnn_outs, self.tgt_logits, self.tgt_transition, self.tgt_loss = compute_tgt_logits(
                    tgt_word_emb)
                if self.cfg.at:
                    perturb_tgt_word_emb = self.add_perturbation(tgt_word_emb, self.tgt_loss, epsilon=self.cfg.epsilon)
                    *_, adv_tgt_loss = compute_tgt_logits(perturb_tgt_word_emb)
                    self.tgt_loss = self.tgt_loss + adv_tgt_loss
                if self.cfg.discriminator != 0:
                    tgt_dis_loss = discriminator(tgt_rnn_outs)
                    self.tgt_loss = self.tgt_loss + tgt_dis_loss
            
            def critic_layer(interpolates,layer_name,is_reuse=None):
                with tf.name_scope(layer_name) as scope:
                    if is_reuse is True:
                        scope.reuse_variables()
                    critic_h1 = fc_layer(interpolates, self.cfg.num_units * 2 * 200 , 1000, layer_name='critic_h1')
                    critic_h2 = fc_layer(critic_h1, 1000, 100, layer_name='critic_h2')
                    critic_out = fc_layer(critic_h2, 100, 1, layer_name='critic_out', act=tf.identity)
                    return critic_out
            src_rnn_outs_flatten = flatten(src_rnn_outs)
            tgt_rnn_outs_flatten = flatten(tgt_rnn_outs)
            alpha = tf.random_uniform(shape=[self.cfg.batch_size,1], minval=0., maxval=1.)
            differences = src_rnn_outs_flatten - tgt_rnn_outs_flatten
            interpolates = tgt_rnn_outs_flatten + (alpha*differences)
            whole = tf.concat([src_rnn_outs_flatten, tgt_rnn_outs_flatten], 0)
            h2_whole = tf.concat([whole, interpolates], 0)
            #可以换一下变为tgt_rnn_outs_flatten - src_rnn_outs_flatten试试效果
            
            # whole = tf.concat([src_rnn_outs_critic, tgt_rnn_outs_critic], 0)
            # out = critic_layer(interpolates,'critic', is_reuse=True)
            # gradients = tf.gradients(critic_layer(interpolates, is_reuse=True), [interpolates])[0]
            # slopes = tf.sqrt(tf.reduce_sum(tf.square(gradients), reduction_indices=[1, 2, 3]))
            # gradient_penalty = tf.reduce_mean((slopes-1.)**2)


        
            with tf.name_scope('critic'):                
                # critic_h1 = fc_layer(interpolates, self.cfg.num_units * 2 * 200 , 1000, layer_name='critic_h1')
                # critic_h2 = fc_layer(critic_h1, 1000, 100, layer_name='critic_h2')
                # critic_out = fc_layer(critic_h2, 100, 1, layer_name='critic_out', act=tf.identity)

                critic_h1_whole = fc_layer(h2_whole, self.cfg.num_units * 2 * 200 , 1000, layer_name='critic_h1_whole')
                critic_h2_whole = fc_layer(critic_h1_whole, 1000, 100, layer_name='critic_h2_whole')
                critic_out_whole = fc_layer(critic_h2_whole, 100, 1, layer_name='critic_out_whole', act=tf.identity)

        critic_s = tf.cond(self.is_train, lambda: tf.slice(critic_out_whole, [0, 0], [self.cfg.batch_size, -1]), lambda: critic_out_whole)
        critic_t = tf.cond(self.is_train, lambda: tf.slice(critic_out_whole, [self.cfg.batch_size , 0 ], [self.cfg.batch_size , -1 ]), lambda: critic_out_whole)
        self.wd_loss = (tf.reduce_mean(critic_s) - tf.reduce_mean(critic_t))
        gradients_whole = tf.gradients(critic_out_whole, [h2_whole])[0]
        slopes = tf.sqrt(tf.reduce_sum(tf.square(gradients_whole), reduction_indices=[1]))
        gradient_penalty = tf.reduce_mean((slopes-1.)**2)        
        # gradients = tf.gradients(critic_out, [interpolates])[0]
        # self.wd_loss = (tf.reduce_mean(critic_s) - tf.reduce_mean(critic_t))
        # slopes = tf.sqrt(tf.reduce_sum(tf.square(gradients), reduction_indices=[1]))
        # gradient_penalty = tf.reduce_mean((slopes-1.)**2)
        # theta_C = [v for v in tf.global_variables() if 'classifier' in v.name]
        theta_D = [v for v in tf.global_variables() if 'critic' in v.name]
        theta_G = [v for v in tf.global_variables() if 'critic' not in v.name]
        self.wd_d_op = tf.train.AdamOptimizer(self.cfg.lr).minimize(-self.wd_loss+self.gp_param*gradient_penalty, var_list=theta_D)
        src_optimizer = tf.train.AdamOptimizer(learning_rate=self.src_lr)
        if self.cfg.grad_clip is not None and self.cfg.grad_clip > 0:
            grads, vs = zip(*src_optimizer.compute_gradients(self.src_loss))
            grads, _ = tf.clip_by_global_norm(grads, self.cfg.grad_clip)
            self.src_train_op = src_optimizer.apply_gradients(zip(grads, vs))
        else:
            self.src_train_op = src_optimizer.minimize(self.src_loss+self.wd_loss,var_list=theta_G)

        tgt_optimizer = tf.train.AdamOptimizer(learning_rate=self.tgt_lr)
        if self.cfg.grad_clip is not None and self.cfg.grad_clip > 0:
            grads, vs = zip(*tgt_optimizer.compute_gradients(self.tgt_loss))
            grads, _ = tf.clip_by_global_norm(grads, self.cfg.grad_clip)
            self.tgt_train_op = tgt_optimizer.apply_gradients(zip(grads, vs))
        else:
            self.tgt_train_op = tgt_optimizer.minimize(self.tgt_loss+self.wd_loss,var_list=theta_G)

    def _src_predict_op(self, data):
        feed_dict = self._get_feed_dict(src_data=data, tgt_data=None, domain_labels=None)
        logits, transition, seq_len = self.sess.run([self.src_logits, self.src_transition, self.src_seq_len],
                                                    feed_dict=feed_dict)
        return self.viterbi_decode(logits, transition, seq_len)

    def _tgt_predict_op(self, data):
        feed_dict = self._get_feed_dict(src_data=None, tgt_data=data, domain_labels=None)
        logits, transition, seq_len = self.sess.run([self.tgt_logits, self.tgt_transition, self.tgt_seq_len],
                                                    feed_dict=feed_dict)
        return self.viterbi_decode(logits, transition, seq_len)

    def train(self, src_dataset, tgt_dataset):
        self.logger.info("Start training...")
        best_f1, no_imprv_epoch, src_lr, tgt_lr, cur_step = -np.inf, 0, self.cfg.lr, self.cfg.lr, 0
        for epoch in range(1, self.cfg.epochs + 1):
            self.logger.info("Epoch {}/{}:".format(epoch, self.cfg.epochs))
            batches = self._arrange_batches(src_dataset, tgt_dataset, self.cfg.mix_rate, self.cfg.train_ratio)
            prog = Progbar(target=len(batches))
            prog.update(0, [("Global Step", int(cur_step)), ("Source Train Loss", 0.0), ("Target Train Loss", 0.0)])
            for i, batch_name in enumerate(batches):
                cur_step += 1
                src_data = src_dataset.get_next_train_batch()
                tgt_data = tgt_dataset.get_next_train_batch()
                for _ in range(self.D_train_num):
                    # domain_labels = [[1, 0]] * data["batch_size"]
                    feed_dict = self._get_feed_dict(src_data=src_data, tgt_data=tgt_data, domain_labels=None,
                                                    is_train=True, src_lr=src_lr)
                    _, wd_loss = self.sess.run([self.wd_d_op,self.wd_loss], feed_dict=feed_dict)

                
                if batch_name == "src":

                    domain_labels = [[1, 0]] * src_data["batch_size"]
                    feed_dict = self._get_feed_dict(src_data=src_data, tgt_data=tgt_data, domain_labels=domain_labels,
                                                    is_train=True, src_lr=src_lr)
                    _, src_cost = self.sess.run([self.src_train_op, self.src_loss], feed_dict=feed_dict)
                    prog.update(i + 1, [("Global Step", int(cur_step)), ("Source Train Loss", src_cost)])
                else:  # "tgt"
                    
                    domain_labels = [[0, 1]] * tgt_data["batch_size"]
                    feed_dict = self._get_feed_dict(src_data=None, tgt_data=tgt_data, domain_labels=domain_labels,
                                                    is_train=True, tgt_lr=tgt_lr)
                    _, tgt_cost = self.sess.run([self.tgt_train_op, self.tgt_loss], feed_dict=feed_dict)
                    prog.update(i + 1, [("Global Step", int(cur_step)), ("Target Train Loss", tgt_cost)])
            if self.cfg.use_lr_decay:  # learning rate decay
                src_lr = max(self.cfg.lr / (1.0 + self.cfg.lr_decay * epoch), self.cfg.minimal_lr)
                if epoch % self.cfg.decay_step == 0:
                    tgt_lr = max(self.cfg.lr / (1.0 + self.cfg.lr_decay * epoch / self.cfg.decay_step),
                                 self.cfg.minimal_lr)
            if not self.cfg.dev_for_train:
                self.evaluate(tgt_dataset.get_data_batches("dev"), "target_dev", self._tgt_predict_op,
                              rev_word_dict=self.rev_tw_dict, rev_label_dict=self.rev_tl_dict)
            score,eval_lines,y_pred,y_true = self.evaluate(tgt_dataset.get_data_batches("test"), "target_test", self._tgt_predict_op,
                                  rev_word_dict=self.rev_tw_dict, rev_label_dict=self.rev_tl_dict)
            if score["FB1"] > best_f1:
                best_f1, no_imprv_epoch = score["FB1"], 0
                self.save_session(epoch)
                save_cr_and_cm(self.rev_tl_dict, y_pred, y_true, thin_yes=True,cr_save_path=os.path.join(self.cfg.checkpoint_path,'cm.csv'), cm_save_path=os.path.join(self.cfg.checkpoint_path,'cm.png'))
                self.logger.info(' -- new BEST score on target test dataset: {:04.2f}'.format(best_f1))
                for line in eval_lines:
                    self.logger.info(line)
                with open(os.path.join(self.cfg.checkpoint_path,'best_dev.txt'),'w+',encoding='utf-8') as f:
                    for line in eval_lines:
                        f.write(line)
                        f.write('\n')
            else:
                no_imprv_epoch += 1
                if self.cfg.no_imprv_tolerance is not None and no_imprv_epoch >= self.cfg.no_imprv_tolerance:
                    self.logger.info('early stop at {}th epoch without improvement'.format(epoch))
                    self.logger.info('best score on target test set: {}'.format(best_f1))
                    break

    def evaluate_data(self, dataset, name, resource="target"):
        if resource == "target":
            self.evaluate(dataset, name, self._tgt_predict_op, self.rev_tw_dict, self.rev_tl_dict)
        else:
            self.evaluate(dataset, name, self._src_predict_op, self.rev_sw_dict, self.rev_sl_dict)
