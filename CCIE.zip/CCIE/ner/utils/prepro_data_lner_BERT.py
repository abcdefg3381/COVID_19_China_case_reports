import collections
import json
import os
import re
import codecs
import tensorflow as tf
import ujson
import emoji
import numpy as np
from tqdm import tqdm
from collections import Counter
from utils.bert import tokenization

from run_classifier_roberta_wwm_large import *
import tokenization

np.random.seed(12345)
# emoji_unicode = {}
# for k, v in emoji.EMOJI_UNICODE.items():
#     emoji_unicode[v]=k
# emoji_unicode = {v: k for k, v in emoji.EMOJI_UNICODE.items()}
glove_sizes = {'6B': int(4e5), '42B': int(1.9e6), '840B': int(2.2e6), '2B': int(1.2e6)}
PAD = "<PAD>"
UNK = "<UNK>"


def write_json(filename, dataset):
    with codecs.open(filename, mode="w", encoding="utf-8") as f:
        ujson.dump(dataset, f)


def iob_to_iobes(labels):
    """IOB -> IOBES"""
    iob_to_iob2(labels)
    new_tags = []
    for i, tag in enumerate(labels):
        if tag == 'O':
            new_tags.append(tag)
        elif tag.split('-')[0] == 'B':
            if i + 1 != len(labels) and labels[i + 1].split('-')[0] == 'I':
                new_tags.append(tag)
            else:
                new_tags.append(tag.replace('B-', 'S-'))
        elif tag.split('-')[0] == 'I':
            if i + 1 < len(labels) and labels[i + 1].split('-')[0] == 'I':
                new_tags.append(tag)
            else:
                new_tags.append(tag.replace('I-', 'E-'))
        else:
            raise Exception('Invalid IOB format!')
    return new_tags


def iob_to_iob2(labels):
    """Check that tags have a valid IOB format. Tags in IOB1 format are converted to IOB2."""
    for i, tag in enumerate(labels):
        if tag == 'O':
            continue
        split = tag.split('-')
        if len(split) != 2 or split[0] not in ['I', 'B']:
            return False
        if split[0] == 'B':
            continue
        elif i == 0 or labels[i - 1] == 'O':  # conversion IOB1 to IOB2
            labels[i] = 'B' + tag[1:]
        elif labels[i - 1][1:] == tag[1:]:
            continue
        else:
            labels[i] = 'B' + tag[1:]
    return True


def word_convert(word, lowercase=True, char_lowercase=False):
    if char_lowercase:
        char = [c for c in word.lower()]
    else:
        char = [c for c in word]
    if lowercase:
        word = word.lower()
    return word, char


# def remove_emoji(line):
#     line = "".join(char for char in line if char not in emoji_unicode)
#     try:
#         pattern = re.compile(u"([\U00002600-\U000027BF])|([\U0001F1E0-\U0001F6FF])")
#     except re.error:
#         pattern = re.compile(u"([\u2600-\u27BF])|([\uD83C][\uDF00-\uDFFF])|([\uD83D][\uDC00-\uDE4F])|"
#                              u"([\uD83D][\uDE80-\uDEFF])")
#     return pattern.sub(r'', line)


# def process_wnut_token(line):
#     line = remove_emoji(line)
#     line = line.lstrip().rstrip().split("\t")
#     if len(line) != 2:
#         return None, None
#     word, label = line[0], line[1]
#     if word.startswith("@") or word.startswith("https://") or word.startswith("http://"):
#         return None, None
#     if word in ["&gt;", "&quot;", "&lt;", ":D", ";)", ":)", "-_-", "=D", ":'", "-__-", ":P", ":p", "RT", ":-)", ";-)",
#                 ":(", ":/"]:
#         return None, None
#     if "&amp;" in word:
#         word = word.replace("&amp;", "&")
#     if word in ["/", "<"] and label == "O":
#         return None, None
#     if len(word) == 0:
#         return None, None
#     return word, label


def process_token(line):
    word, *_, label = line.split(" ")
    if "page=http" in word or "http" in word:
        return None, None
    return word, label


def raw_dataset_iter(filename, data_type, lowercase=True, char_lowercase=False):
    #lner数据格式是三行，如果普通得数据就得将word,thick_label,thin_label = line.split(' ')
    #修改为word,label = line.split(' ')
    with codecs.open(filename, mode="r", encoding="utf-8") as f:
        words, labels = [], [] 
        flag = 0
        for line in f:
            flag += 1
            line = line.lstrip().rstrip()
            if len(line) == 0 or line.startswith("-DOCSTART-"):
                if len(words) != 0:
                    yield words, labels #返回words, labels，下次调用next()时从此处开始执行
                    words, labels = [], []
            else:
                if data_type=='thick' or data_type=='thin':
                    word,thick_label,thin_label = line.split(' ')
                    #lner数据格式是三行，如果普通得数据就得将word,thick_label,thin_label = line.split(' ')
                    #修改为word,label = line.split(' ')
                    # word,label = line.split(' ')
                    if word is None or thick_label is None or thin_label is None:
                        continue
                    if data_type == 'thick':
                        words.append(word)
                        labels.append(thick_label)
                    elif data_type == 'thin':
                        words.append(word)
                        labels.append(thin_label)
                elif data_type=='drug':
                    try:
                        word,label = line.split('\t')
                    except :
                        print(flag)
                        continue
                    if word is None or label is None:
                        continue                    
                    words.append(word)
                    labels.append(label)
                # thin_labels.append(thin_label)
        if len(words) != 0:
            yield words, labels

def load_dataset(filename, iobes, data_type, lowercase=True, char_lowercase=False):
    dataset = []
    
    for words, labels in raw_dataset_iter(filename,data_type, lowercase, char_lowercase):
        if iobes:
            labels = iob_to_iobes(labels)
        dataset.append({"words": words,  "labels": labels})   

    return dataset

def load_emb_vocab(data_path, language, dim):
    vocab = list()
    with codecs.open(data_path, mode="r", encoding="utf-8") as f:
        if "glove" in data_path:
            total = glove_sizes[data_path.split(".")[-3]]
        else:
            total = int(f.readline().lstrip().rstrip().split(" ")[0])
        for line in tqdm(f, total=total, desc="Load {} embedding vocabulary".format(language)):
            line = line.lstrip().rstrip().split(" ")
            if len(line) == 2:
                continue
            if len(line) != dim + 1:
                continue
            word = line[0]
            vocab.append(word)
    return vocab


def filter_emb(word_dict, data_path, language, dim):
    vectors = np.zeros([len(word_dict), dim])
    with codecs.open(data_path, mode="r", encoding="utf-8") as f:
        if "glove" in data_path:
            total = glove_sizes[data_path.split(".")[-3]]
        else:
            total = int(f.readline().lstrip().rstrip().split(" ")[0])
        for line in tqdm(f, total=total, desc="Load {} embedding vectors".format(language)):
            line = line.lstrip().rstrip().split(" ")
            if len(line) == 2:
                continue
            if len(line) != dim + 1:
                continue
            word = line[0]
            if word in word_dict:
                vector = [float(x) for x in line[1:]]
                word_idx = word_dict[word]
                vectors[word_idx] = np.asarray(vector)
    return vectors


def build_token_counters(datasets):
    word_counter = Counter()
    label_counter = Counter()
    for dataset in datasets:
        for record in dataset:
            for word in record["words"]:
                word_counter[word] += 1

            for label in record["labels"]:
                label_counter[label] += 1
    return word_counter,  label_counter

def build_token_counters_split(datasets):
    word_counter = Counter()
    label_counter = Counter()
    label_list = []
    for dataset in datasets:
        for record in dataset:
            for word in record["words"]:
                word_counter[word] += 1

            for label in record["labels"]:
                label_counter[label] += 1
        label_list.append(label_counter)
    return word_counter,  label_counter , label_list

def build_dataset(data, word_dict, label_dict):
    dataset = []
    for record in data:
        words = []
        for word in record["words"]:
            words.append(word_dict[word] if word in word_dict else word_dict[UNK])        
        labels = [label_dict[label] for label in record["labels"]]
        dataset.append({"words": words,  "labels": labels})
    return dataset


def read_data_and_vocab(train_file, dev_file, test_file, data_type, config):
    train_data = load_dataset(train_file, iobes=config.iobes, data_type=data_type, lowercase=config.word_lowercase,
                              char_lowercase=config.char_lowercase)#默认是bio
    dev_data = load_dataset(dev_file, iobes=config.iobes, data_type=data_type, lowercase=config.word_lowercase,
                            char_lowercase=config.char_lowercase)
    test_data = load_dataset(test_file, iobes=config.iobes, data_type=data_type, lowercase=config.word_lowercase,
                             char_lowercase=config.char_lowercase)
    
    word_counter,  label_counter = build_token_counters([train_data, dev_data, test_data])
    return train_data, dev_data, test_data, word_counter, label_counter


def read_data_and_vocab_for_contunt(train_file, dev_file, test_file, data_type, config):
    train_data = load_dataset(train_file, iobes=config.iobes, data_type=data_type, lowercase=config.word_lowercase,
                              char_lowercase=config.char_lowercase)
    dev_data = load_dataset(dev_file, iobes=config.iobes, data_type=data_type, lowercase=config.word_lowercase,
                            char_lowercase=config.char_lowercase)
    test_data = load_dataset(test_file, iobes=config.iobes, data_type=data_type, lowercase=config.word_lowercase,
                             char_lowercase=config.char_lowercase)
    
    word_counter,  label_counter, label_list = build_token_counters_split([train_data, dev_data, test_data])
    return train_data, dev_data, test_data, word_counter, label_counter, label_list

def write_to_jsons(datasets, files, save_path):
    for dataset, file in zip(datasets, files):
        write_json(os.path.join(save_path, file), dataset)


def process_word_counter(word_counter, wordvec_path, wordvec, language, word_dim, word_weight):
    word_vocab = [word for word, _ in word_counter.most_common()]
    if wordvec is not None:
        emb_vocab = load_emb_vocab(wordvec_path, language=language, dim=word_dim)
        word_vocab = list(set(word_vocab) & set(emb_vocab))
        tmp_word_dict = dict([(word, idx) for idx, word in enumerate(word_vocab)])
        vectors = filter_emb(tmp_word_dict, wordvec_path, language, word_dim)
        np.savez_compressed(wordvec, embeddings=np.asarray(vectors))
    word_vocab = [PAD, UNK] + word_vocab
    word_dict = dict([(word, idx) for idx, word in enumerate(word_vocab)])
    # create word weight for adversarial training
    word_count = dict()
    for word, count in word_counter.most_common():
        if word in word_dict:
            word_count[word] = word_count.get(word, 0) + count
        else:
            word_count[UNK] = word_count.get(UNK, 0) + count
    sum_word_count = float(sum(list(word_count.values())))
    word_weight_vec = [float(word_count[word]) / sum_word_count for word in word_vocab[1:]]
    np.savez_compressed(word_weight, embeddings=np.asarray(word_weight_vec))
    return word_dict


def process_char_counter(char_counter, threshold, char_weight):
    char_vocab = [PAD, UNK] + [char for char, count in char_counter.most_common() if count >= threshold]
    char_dict = dict([(char, idx) for idx, char in enumerate(char_vocab)])
    # create character weight for adversarial training
    char_count = dict()
    for char, count in char_counter.most_common():
        if char in char_dict:
            char_count[char] = char_count.get(char, 0) + count
        else:
            char_count[UNK] = char_count.get(UNK, 0) + count
    sum_char_count = float(sum(list(char_count.values())))
    char_weight_vec = [float(char_count[char]) / sum_char_count for char in char_vocab[1:]]  # exclude PAD
    np.savez_compressed(char_weight, embeddings=np.asarray(char_weight_vec))
    return char_dict




def process_one_example(tokenizer, label2id, text, label, max_seq_len=128):
    # textlist = text.split(' ')
    # labellist = label.split(' ')
    textlist = list(text)
    labellist = list(label)
    tokens = []
    labels = []
    for i, word in enumerate(textlist):
        token = tokenizer.tokenize(word)
        tokens.extend(token)
        label_1 = labellist[i]
        for m in range(len(token)):
            if m == 0:
                labels.append(label_1)
            else:
                print("some unknown token...")
                labels.append(labels[0])
    # tokens = tokenizer.tokenize(example.text)  -2 的原因是因为序列需要加一个句首和句尾标志
    if len(tokens) >= max_seq_len - 1:
        tokens = tokens[0:(max_seq_len - 2)]
        labels = labels[0:(max_seq_len - 2)]
    ntokens = []
    segment_ids = []
    label_ids = []
    ntokens.append("[CLS]")  # 句子开始设置CLS 标志
    segment_ids.append(0)
    # [CLS] [SEP] 可以为 他们构建标签，或者 统一到某个标签，反正他们是不变的，基本不参加训练 即：x-l 永远不变
    label_ids.append(label2id["[CLS]"])  # label2id["[CLS]"]
    for i, token in enumerate(tokens):
        ntokens.append(token)
        segment_ids.append(0)
        label_ids.append(label2id[labels[i]])
    ntokens.append("[SEP]")
    segment_ids.append(0)
    # append("O") or append("[SEP]") not sure!
    label_ids.append(label2id["[SEP]"])  # label2id["[SEP]"]
    input_ids = tokenizer.convert_tokens_to_ids(ntokens)
    input_mask = [1] * len(input_ids)
    while len(input_ids) < max_seq_len:
        input_ids.append(0)
        input_mask.append(0)
        segment_ids.append(0)
        label_ids.append(0)
        ntokens.append("**NULL**")
    assert len(input_ids) == max_seq_len
    assert len(input_mask) == max_seq_len
    assert len(segment_ids) == max_seq_len
    assert len(label_ids) == max_seq_len

    feature = (input_ids, input_mask, segment_ids, label_ids)
    return feature


def prepare_tf_record_data(tokenizer, max_seq_len, label2id, dataset, out_path):
    """
        生成训练数据， tf.record, 单标签分类模型, 随机打乱数据
    """
    writer = tf.python_io.TFRecordWriter(out_path)
    example_count = 0
    # words = []
    # tags = []
    for i in range(len(dataset["words"])):
        for word,label in zip(dataset["words"][i],dataset["labels"][i]):
 
            # words.append(word)
            # tags.append(label)
            feature = process_one_example(tokenizer, label2id, word, label,
                                        max_seq_len=max_seq_len)

            def create_int_feature(values):
                f = tf.train.Feature(int64_list=tf.train.Int64List(value=list(values)))
                return f

            features = collections.OrderedDict()
            # 序列标注任务
            features["input_ids"] = create_int_feature(feature[0])
            features["input_mask"] = create_int_feature(feature[1])
            features["segment_ids"] = create_int_feature(feature[2])
            features["label_ids"] = create_int_feature(feature[3])
            if example_count < 5:
                print("*** Example ***")
                print(word)
                print(label)
                print("input_ids: %s" % " ".join([str(x) for x in feature[0]]))
                print("input_mask: %s" % " ".join([str(x) for x in feature[1]]))
                print("segment_ids: %s" % " ".join([str(x) for x in feature[2]]))
                print("label: %s " % " ".join([str(x) for x in feature[3]]))

            tf_example = tf.train.Example(features=tf.train.Features(feature=features))
            writer.write(tf_example.SerializeToString())
            example_count += 1

            if example_count % 3000 == 0:
                print(example_count)
    print("total example:", example_count)
    writer.close()



def process_base_bert(config):


    processors = {
            "ner": NerProcessor
        }

    tokenization.validate_case_matches_checkpoint(config.word_lowercase,
                                                  config.bert_model_path)
    
    bert_config = modeling.BertConfig.from_json_file(config.bert_config) # 配置文件地址。

    if config.max_seq_len > bert_config.max_position_embeddings:
        raise ValueError(
            "Cannot use sequence length %d because the BERT model "
            "was only trained up to sequence length %d" %
            ( config.max_seq_len, bert_config.max_position_embeddings))

    task_name = config.task_name.lower()

    if task_name not in processors:
        raise ValueError("Task not found: %s" % (task_name))


    train_data, dev_data, test_data, _,  label_counter = read_data_and_vocab(
        config.train_file, config.dev_file, config.test_file, data_type=config.data_type, config=config)#
    
    label_list = ["O"] + [label for label, _ in label_counter.most_common() if label != "O"]
    label2id = dict([(label, idx) for idx, label in enumerate(label_list)])
    label2id['[CLS]'] = len(label2id)
    label2id['[SEP]'] = len(label2id)
    config.num_labels = len(label2id)
    config.lable2id = label2id
    # create save path
    if not os.path.exists(config.save_path):
        os.makedirs(config.save_path)
    with open(os.path.join(config.save_path,"label2id.json"), "w") as f:
        f.write(json.dumps(label2id, ensure_ascii=False, indent=4, separators=(',', ':')))

    processor = processors[task_name]()
    tokenizer = tokenization.FullTokenizer(
        vocab_file=config.vocab_file, do_lower_case=config.word_lowercase)

    train_examples = create_examples(train_data)
    dev_examples = create_examples(dev_data)
    test_examples = create_examples(test_data)

    print("convertint examples to features ........")
    train_features = file_based_convert_examples_to_features(
        train_examples, label_list, config.max_seq_len, tokenizer, config.train_set)    
    dev_features = file_based_convert_examples_to_features(
        dev_examples, label_list, config.max_seq_len, tokenizer, config.dev_set)
    test_features = file_based_convert_examples_to_features(
        test_examples, label_list, config.max_seq_len, tokenizer, config.test_set)
    return [train_features,dev_features,test_features]



def process_transfer_bert(config):


    processors = {
            "ner": NerProcessor
        }

    tokenization.validate_case_matches_checkpoint(config.word_lowercase,
                                                  config.bert_model_path)
    bert_config = modeling.BertConfig.from_json_file(config.bert_config)

    if config.max_seq_len > bert_config.max_position_embeddings:
        raise ValueError(
            "Cannot use sequence length %d because the BERT model "
            "was only trained up to sequence length %d" %
            ( config.max_seq_len, bert_config.max_position_embeddings))

    
    if not os.path.exists(config.save_path):
        os.makedirs(config.save_path)

    task_name = config.task_name.lower()

    if task_name not in processors:
        raise ValueError("Task not found: %s" % (task_name))

    s_train_data, s_dev_data, s_test_data, _,  s_label_counter = read_data_and_vocab(
        config.src_train_file, config.src_dev_file, config.src_test_file, data_type=config.src_data_type, config=config)
    t_train_data, t_dev_data, t_test_data, _, t_label_counter = read_data_and_vocab(
        config.tgt_train_file, config.tgt_dev_file, config.tgt_test_file, data_type=config.tgt_data_type, config=config)

    if config.share_label:
        s_label_counter = s_label_counter + t_label_counter
        label_list = ["O"] + [label for label, _ in s_label_counter.most_common() if label != "O"]
        src_label_list = label_list.copy()
        tgt_label_list = label_list.copy()
        label2id = dict([(label, idx) for idx, label in enumerate(label_list)])
        label2id['[CLS]'] = len(label2id)
        label2id['[SEP]'] = len(label2id)
        config.src_label2id = label2id.copy()
        config.tgt_label2id = label2id.copy()

    else:
        src_label_list = ["O"] + [label for label, _ in s_label_counter.most_common() if label != "O"]
        config.src_label2id = dict([(label, idx) for idx, label in enumerate(src_label_list)])
        config.src_label2id['[CLS]'] = len(config.src_label2id)
        config.src_label2id['[SEP]'] = len(config.src_label2id)
        tgt_label_list = ["O"] + [label for label, _ in t_label_counter.most_common() if label != "O"]
        config.tgt_label2id = dict([(label, idx) for idx, label in enumerate(tgt_label_list)])
        config.tgt_label2id['[CLS]'] = len(config.tgt_label2id)
        config.tgt_label2id['[SEP]'] = len(config.tgt_label2id)
    
    processor = processors[task_name]()
    tokenizer = tokenization.FullTokenizer(
        vocab_file=config.vocab_file, do_lower_case=config.word_lowercase)
    
    s_train_examples = create_examples(s_train_data)
    s_dev_examples = create_examples(s_dev_data)
    s_test_examples = create_examples(s_test_data)
    t_train_examples = create_examples(t_train_data)
    t_dev_examples = create_examples(t_dev_data)
    t_test_examples = create_examples(t_test_data)


    print("convertint examples to features ........")
    s_train_features = file_based_convert_examples_to_features(
        s_train_examples, src_label_list, config.max_seq_len, tokenizer, config.src_train_set)    
    s_dev_features = file_based_convert_examples_to_features(
        s_dev_examples, src_label_list, config.max_seq_len, tokenizer, config.src_dev_set)
    s_test_features = file_based_convert_examples_to_features(
        s_test_examples, src_label_list, config.max_seq_len, tokenizer, config.src_test_set)
    t_train_features = file_based_convert_examples_to_features(
        t_train_examples, tgt_label_list, config.max_seq_len, tokenizer, config.tgt_train_set)    
    t_dev_features = file_based_convert_examples_to_features(
        t_dev_examples, tgt_label_list, config.max_seq_len, tokenizer, config.tgt_dev_set)
    t_test_features = file_based_convert_examples_to_features(
        t_test_examples, tgt_label_list, config.max_seq_len, tokenizer, config.tgt_test_set)


    return [s_train_features,s_dev_features,s_test_features],[t_train_features,t_dev_features,t_test_features]

def process_transfer(config):
    s_train_data, s_dev_data, s_test_data, _,  s_label_counter = read_data_and_vocab(
        config.src_train_file, config.src_dev_file, config.src_test_file, data_type=config.src_data_type, config=config)
    t_train_data, t_dev_data, t_test_data, _, t_label_counter = read_data_and_vocab(
        config.tgt_train_file, config.tgt_dev_file, config.tgt_test_file, data_type=config.tgt_data_type, config=config)
    # create save path
    if not os.path.exists(config.save_path):
        os.makedirs(config.save_path)
    # build char vocab
    # s_char_counter = s_char_counter + t_char_counter
    # char_dict = process_char_counter(s_char_counter, config.threshold, config.char_weight)
    # build label vocab

    if config.share_label:
        s_label_counter = s_label_counter + t_label_counter
        label_vocab = ["O"] + [label for label, _ in s_label_counter.most_common() if label != "O"]
        label2id = dict([(label, idx) for idx, label in enumerate(label_vocab)])
        label2id['[CLS]'] = len(label2id)
        label2id['[SEP]'] = len(label2id)
        config.src_label2id = label2id.copy()
        config.tgt_label2id = label2id.copy()

    else:
        src_label_vocab = ["O"] + [label for label, _ in s_label_counter.most_common() if label != "O"]
        config.src_label2id = dict([(label, idx) for idx, label in enumerate(src_label_vocab)])
        config.src_label2id['[CLS]'] = len(config.src_label2id)
        config.src_label2id['[SEP]'] = len(config.src_label2id)
        tgt_label_vocab = ["O"] + [label for label, _ in t_label_counter.most_common() if label != "O"]
        config.tgt_label2id = dict([(label, idx) for idx, label in enumerate(tgt_label_vocab)])
        config.tgt_label2id['[CLS]'] = len(config.tgt_label2id)
        config.tgt_label2id['[SEP]'] = len(config.tgt_label2id)
    
    with open(os.path.join(config.save_path,"src_label2id.json"), "w+") as f:
        f.write(json.dumps(config.src_label2id, ensure_ascii=False, indent=4, separators=(',', ':')))
    with open(os.path.join(config.save_path,"tgt_label2id.json"), "w") as f:
        f.write(json.dumps( config.tgt_label2id, ensure_ascii=False, indent=4, separators=(',', ':')))
    # create indices dataset
    tokenizer = tokenization.FullTokenizer(vocab_file=config.vocab_file)

    prepare_tf_record_data(tokenizer, config.max_seq_len, config.src_label2id, s_train_data,
                           out_path=os.path.join(config.save_path,"src_train.tf_record"))
    prepare_tf_record_data(tokenizer, config.max_seq_len, config.src_label2id, s_dev_data,
                           out_path=os.path.join(config.save_path,"src_dev.tf_record"))
    prepare_tf_record_data(tokenizer, config.max_seq_len, config.src_label2id, s_test_data,
                           out_path=os.path.join(config.save_path,"src_test.tf_record"))

    prepare_tf_record_data(tokenizer, config.max_seq_len, config.tgt_label2id, t_train_data,
                           out_path=os.path.join(config.save_path,"tgt_train.tf_record"))
    prepare_tf_record_data(tokenizer, config.max_seq_len, config.tgt_label2id, t_dev_data,
                           out_path=os.path.join(config.save_path,"tgt_dev.tf_record"))
    prepare_tf_record_data(tokenizer, config.max_seq_len, config.tgt_label2id, t_test_data,
                           out_path=os.path.join(config.save_path,"tgt_test.tf_record"))





def process_one_example(tokenizer, label2id, text, label, max_seq_len=128):
    # textlist = text.split(' ')
    # labellist = label.split(' ')
    textlist = list(text)
    labellist = list(label)
    tokens = []
    labels = []
    for i, word in enumerate(textlist):
        token = tokenizer.tokenize(word)
        tokens.extend(token)
        label_1 = labellist[i]
        for m in range(len(token)):
            if m == 0:
                labels.append(label_1)
            else:
                print("some unknown token...")
                labels.append(labels[0])
    # tokens = tokenizer.tokenize(example.text)  -2 的原因是因为序列需要加一个句首和句尾标志
    if len(tokens) >= max_seq_len - 1:
        tokens = tokens[0:(max_seq_len - 2)]
        labels = labels[0:(max_seq_len - 2)]
    ntokens = []
    segment_ids = []
    label_ids = []
    ntokens.append("[CLS]")  # 句子开始设置CLS 标志
    segment_ids.append(0)
    # [CLS] [SEP] 可以为 他们构建标签，或者 统一到某个标签，反正他们是不变的，基本不参加训练 即：x-l 永远不变
    label_ids.append(label2id["[CLS]"])  # label2id["[CLS]"]
    for i, token in enumerate(tokens):
        ntokens.append(token)
        segment_ids.append(0)
        label_ids.append(label2id[labels[i]])
    ntokens.append("[SEP]")
    segment_ids.append(0)
    # append("O") or append("[SEP]") not sure!
    label_ids.append(label2id["[SEP]"])  # label2id["[SEP]"]
    input_ids = tokenizer.convert_tokens_to_ids(ntokens)
    input_mask = [1] * len(input_ids)
    while len(input_ids) < max_seq_len:
        input_ids.append(0)
        input_mask.append(0)
        segment_ids.append(0)
        label_ids.append(0)
        ntokens.append("**NULL**")
    assert len(input_ids) == max_seq_len
    assert len(input_mask) == max_seq_len
    assert len(segment_ids) == max_seq_len
    assert len(label_ids) == max_seq_len

    feature = (input_ids, input_mask, segment_ids, label_ids)
    return feature


def prepare_tf_record_data(tokenizer, max_seq_len, label2id, dataset, out_path):
    """
        生成训练数据， tf.record, 单标签分类模型, 随机打乱数据
    """
    writer = tf.python_io.TFRecordWriter(out_path)
    example_count = 0
    # words = []
    # tags = []
    for i in range(len(dataset)): 
        # words.append(word)
        # tags.append(label)
        feature = process_one_example(tokenizer, label2id, dataset[i]["words"], dataset[i]["labels"],
                                    max_seq_len=max_seq_len)

        def create_int_feature(values):
            f = tf.train.Feature(int64_list=tf.train.Int64List(value=list(values)))
            return f

        features = collections.OrderedDict()
        # 序列标注任务
        features["input_ids"] = create_int_feature(feature[0])
        features["input_mask"] = create_int_feature(feature[1])
        features["segment_ids"] = create_int_feature(feature[2])
        features["label_ids"] = create_int_feature(feature[3])
        if example_count < 5:
            print("*** Example ***")
            print(dataset[i]["words"])
            print( dataset[i]["labels"])
            print("input_ids: %s" % " ".join([str(x) for x in feature[0]]))
            print("input_mask: %s" % " ".join([str(x) for x in feature[1]]))
            print("segment_ids: %s" % " ".join([str(x) for x in feature[2]]))
            print("label: %s " % " ".join([str(x) for x in feature[3]]))

        tf_example = tf.train.Example(features=tf.train.Features(feature=features))
        writer.write(tf_example.SerializeToString())
        example_count += 1

        if example_count % 3000 == 0:
            print(example_count)
    print("total example:", example_count)
    writer.close()
