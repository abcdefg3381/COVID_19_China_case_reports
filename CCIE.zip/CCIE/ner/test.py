# %%
import codecs
from utils.prepro_data import iob_to_iobes

def load_dataset_lner(filename, iobes, type, lowercase=True, char_lowercase=False):
    dataset = []
    
    for words, labels in raw_dataset_iter_lner(filename,type, lowercase, char_lowercase):
        if iobes:
            labels = iob_to_iobes(labels)
        dataset.append({"words": words,  "labels": labels})
    return dataset

def raw_dataset_iter_lner(filename, type, lowercase=True, char_lowercase=False):
    with codecs.open(filename, mode="r", encoding="utf-8") as f:
        words, labels = [], [] 
        for line in f:
            line = line.lstrip().rstrip()
            if len(line) == 0 or line.startswith("-DOCSTART-"):
                if len(words) != 0:
                    yield words, labels
                    words, labels = [], []
            else:
                word,thick_label,thin_label = line.split(' ')
                if word is None or thick_label is None or thin_label is None:
                    continue
                if type == 'thick':
                    words.append(word)
                    labels.append(thick_label)
                elif type == 'thin':
                    words.append(word)
                    labels.append(thin_label)
                # thin_labels.append(thin_label)
        if len(words) != 0:
            yield words, labels
# %%
from collections import Counter

def build_token_counters(datasets):
    word_counter = Counter()
    label_counter = Counter()
    for dataset in datasets:
        for record in dataset:
            for word in record["words"]:
                word_counter[word] += 1

            for label in record["labels"]:
                label_counter[label] += 1
    return word_counter,  label_counter

def read_data_and_vocab(train_file, dev_file, test_file, type, config):
    train_data = load_dataset_lner(train_file, False, type)
    dev_data = load_dataset_lner(dev_file, False, type)
    test_data = load_dataset_lner(test_file, False, type)
    word_counter,  label_counter = build_token_counters([train_data, dev_data, test_data])
    return train_data, dev_data, test_data, word_counter,  label_counter

train_file = "mlt_lner/train.txt"
dev_file = "mlt_lner/dev.txt"
test_file = "mlt_lner/test.txt"
train_data, dev_data, test_data, word_counter, label_counter = read_data_and_vocab(
                        train_file=train_file,
                        dev_file=dev_file,
                        test_file=test_file,
                        type='thick',
                        config=True
                        )
# %%
from utils.prepro_data import load_emb_vocab,filter_emb
import numpy as np
PAD = "<PAD>"
UNK = "<UNK>"

def process_word_counter(word_counter, wordvec_path, wordvec, language, word_dim, word_weight):
    word_vocab = [word for word, _ in word_counter.most_common()]
    if wordvec is not None:
        emb_vocab = load_emb_vocab(wordvec_path, language=language, dim=word_dim)
        word_vocab = list(set(word_vocab) & set(emb_vocab))
        tmp_word_dict = dict([(word, idx) for idx, word in enumerate(word_vocab)])
        vectors = filter_emb(tmp_word_dict, wordvec_path, language, word_dim)
        np.savez_compressed(wordvec, embeddings=np.asarray(vectors))
    word_vocab = [PAD, UNK] + word_vocab
    word_dict = dict([(word, idx) for idx, word in enumerate(word_vocab)])
    # create word weight for adversarial training
    word_count = dict()
    for word, count in word_counter.most_common():
        if word in word_dict:
            word_count[word] = word_count.get(word, 0) + count
        else:
            word_count[UNK] = word_count.get(UNK, 0) + count
    sum_word_count = float(sum(list(word_count.values())))
    word_weight_vec = [float(word_count[word]) / sum_word_count for word in word_vocab[1:]]
    np.savez_compressed(word_weight, embeddings=np.asarray(word_weight_vec))
    return word_dict


# %%
from utils.prepro_data import load_emb_vocab,filter_emb
import numpy as np
PAD = "<PAD>"
UNK = "<UNK>"

wordvec_path = "/home/sda/lichunnan/backup/embeding/sgns.wiki.word"
wordvec ="mlt_lner/wordvec.npz"
word_weight = 'mlt_lner/word_weight.npz'
word_dim =300
word_dict = process_word_counter(word_counter, wordvec_path, wordvec, 'chinese',
                                    300, word_weight)

# %%
label_vocab = ["O"] + [label for label, _ in label_counter.most_common() if label != "O"]
label_dict = dict([(label, idx) for idx, label in enumerate(label_vocab)])# %%

# %%

def build_dataset(data, word_dict, label_dict):
    dataset = []
    for record in data:
        words = []
        for word in record["words"]:
            words.append(word_dict[word] if word in word_dict else word_dict[UNK])        
        labels = [label_dict[label] for label in record["labels"]]
        dataset.append({"words": words,  "labels": labels})
    return dataset
train_set = build_dataset(train_data, word_dict,  label_dict)
# %%
from utils.prepro_data_lner import process_word_counter
word_dict = process_word_counter(word_counter, wordvec_path, wordvec, 'chinese',
                                    300, word_weight)
# %%
from utils.prepro_data_lner import build_dataset

train_set = build_dataset(train_data, word_dict, label_dict)

# %%
train_data, dev_data, test_data, word_counter, char_counter, label_counter = read_data_and_vocab(
    config.train_file, config.dev_file, config.test_file, language=config.language, config=config)
# create save path
if not os.path.exists(config.save_path):
    os.makedirs(config.save_path)
# build word vocab
word_dict = process_word_counter(word_counter, config.wordvec_path, config.wordvec, config.language,
                                    config.word_dim, config.word_weight)

# build label vocab
label_vocab = ["O"] + [label for label, _ in label_counter.most_common() if label != "O"]
label_dict = dict([(label, idx) for idx, label in enumerate(label_vocab)])
# create indices dataset
if config.dev_for_train:
    train_data = train_data + dev_data
train_set = build_dataset(train_data, word_dict, char_dict, label_dict)
dev_set = build_dataset(dev_data, word_dict, char_dict, label_dict)
test_set = build_dataset(test_data, word_dict, char_dict, label_dict)
vocab = {"word_dict": word_dict, "char_dict": char_dict, "label_dict": label_dict}
# write to json
write_to_jsons([train_set, dev_set, test_set, vocab], ["train.json", "dev.json", "test.json", "vocab.json"],
                config.save_path)
# %%
EMB_PATH = os.path.join(os.path.expanduser('~'), "utilities", "embeddings", "monolingual")

# %%
EMB_PATH
# %%
import time
since = time.time()
time.sleep(5)
end = time.time()
time_elapsed = time.time() - since
print(since,time_elapsed)
print('The code run{:.0f}s'.format(time_elapsed))
# %%
from utils.prepro_data_lner import raw_dataset_iter,iob_to_iobes,read_data_and_vocab
from data_processor_seq import process_one_example
import json
from utils.bert import tokenization
import collections
import tensorflow as tf

filename= "datasets/raw/mlt_lner/train.txt"
iobes=False
data_type= "thin"
lowercase=False
char_lowercase=False
max_seq_len = 256


vocab_file = "utils/bert/vocab.txt"
tokenizer = tokenization.FullTokenizer(vocab_file=vocab_file)
label2id = json.loads(open("label2id.json").read())

label2id['[CLS]'] = len(label2id)
label2id['[SEP]'] = len(label2id)
# train_data, dev_data, test_data, word_counter,  label_counter = read_data_and_vocab(
#         config.train_file, config.dev_file, config.test_file, data_type=config.data_type, config=config)

# label_vocab = ["O"] + [label for label, _ in label_counter.most_common() if label != "O"]
# label2id = dict([(label, idx) for idx, label in enumerate(label_vocab)])

def create_int_feature(values):
    f = tf.train.Feature(int64_list=tf.train.Int64List(value=list(values)))
    return f


out_path = "dev.tf_record"
writer = tf.python_io.TFRecordWriter(out_path)
example_count = 0
dataset = []
words =[]
tags = []
for word, label in raw_dataset_iter(filename,data_type, lowercase, char_lowercase):
    if iobes:
        labels = iob_to_iobes(label)
    words.append(word)
    tags.append(label)   
    feature = process_one_example(tokenizer, label2id, word, label,
                                      max_seq_len=max_seq_len)    


    features = collections.OrderedDict()
    features["input_ids"] = create_int_feature(feature[0])
    features["input_mask"] = create_int_feature(feature[1])
    features["segment_ids"] = create_int_feature(feature[2])
    features["label_ids"] = create_int_feature(feature[3])

    if example_count < 5:
        print("*** Example ***")
        print(word)
        print(label)
        print("input_ids: %s" % " ".join([str(x) for x in feature[0]]))
        print("input_mask: %s" % " ".join([str(x) for x in feature[1]]))
        print("segment_ids: %s" % " ".join([str(x) for x in feature[2]]))
        print("label: %s " % " ".join([str(x) for x in feature[3]]))

    tf_example = tf.train.Example(features=tf.train.Features(feature=features))
    writer.write(tf_example.SerializeToString())
    example_count += 1
    if example_count % 3000 == 0:
        print(example_count)
print("total example:", example_count)
writer.close()

# %%
from utils.prepro_data_lner import raw_dataset_iter,iob_to_iobes,read_data_and_vocab

import json
from utils.bert import tokenization
import collections
import tensorflow as tf
label2id = json.loads(open("label2id.json").read())

# %%
with open("datasets/raw/baseinf2/test.txt",'r',encoding='utf-8') as f:
    all_word, all_label = [],[]
    words, labels = [], [] 
    flag = 0
    for line in f:
        flag += 1
        line = line.lstrip().rstrip()
        if len(line) == 0 or line.startswith("-DOCSTART-"):
            if len(words) != 0:
                all_word.append( words)
                all_label.append(labels)
                words, labels = [], []
        else:
            if data_type=='thick' or data_type=='thin':
                word,thick_label,thin_label = line.split(' ')
                #lner数据格式是三行，如果普通得数据就得将word,thick_label,thin_label = line.split(' ')
                #修改为word,label = line.split(' ')
                # word,label = line.split(' ')
                if word is None or thick_label is None or thin_label is None:
                    continue
                if data_type == 'thick':
                    words.append(word)
                    labels.append(thick_label)
                elif data_type == 'thin':
                    words.append(word)
                    labels.append(thin_label)
            elif data_type=='drug':
                try:
                    word,label = line.split('\t')
                except :
                    print(flag)
                    continue
                if word is None or label is None:
                    continue                    
                words.append(word)
                labels.append(label)
            # thin_labels.append(thin_label)
    if len(words) != 0:
        all_word.append( words)
        all_label.append(labels)