import math
import tensorflow as tf
import numpy as np
from models.shares import Base, BiRNN, CharTDNNHW, CRF, Embedding, save_cr_and_cm, print_config
from utils.logger import Progbar
import os
from utils.bert import modeling
from bert.modeling import BertConfig, BertModel
import tokenization

class BaseModel(Base):
    """Basement model: Char CNN + LSTM encoder + Chain CRF decoder module"""
    def __init__(self, config):
        super(BaseModel, self).__init__(config)
        self._init_configs()

        with tf.Graph().as_default():           
            
            
            self._add_placeholders()
            self._build_model()
            self.logger.info("total params: {}".format(self.count_params()))
            print_config(config,self.logger,Base=True)
            self._initialize_session()
            

    def _init_configs(self):
        vocab = self.load_dataset(self.cfg.vocab)
        self.word_dict, self.label_dict = vocab["word_dict"], vocab["label_dict"]
        self.word_size, self.label_size = len(self.word_dict), len(self.label_dict)
        self.rev_word_dict = dict([(idx, word) for word, idx in self.word_dict.items()])       
        self.rev_label_dict = dict([(idx, tag) for tag, idx in self.label_dict.items()])

    def _get_feed_dict(self, data, is_train=False, lr=None):
        feed_dict = {self.words: data["words"], self.seq_len: data["seq_len"] }
        if "labels" in data:
            feed_dict[self.labels] = data["labels"]
        feed_dict[self.is_train] = is_train
        if lr is not None:
            feed_dict[self.lr] = lr
        return feed_dict

    def _add_placeholders(self):
        self.words = tf.placeholder(tf.int32, shape=[None, None], name="words")
        self.seq_len = tf.placeholder(tf.int32, shape=[None], name="seq_len")
        # self.chars = tf.placeholder(tf.int32, shape=[None, None, None], name="chars")
        # self.char_seq_len = tf.placeholder(tf.int32, shape=[None, None], name="char_seq_len")
        self.labels = tf.placeholder(tf.int32, shape=[None, None], name="labels")
        self.is_train = tf.placeholder(tf.bool, shape=[], name="is_train")
        self.lr = tf.placeholder(tf.float32, name="learning_rate")        
        self.loss_summary = tf.Variable(0.0, dtype=tf.float32,trainable=False)
        self.mean_loss_summary = tf.Variable(0.0,dtype=tf.float32, trainable=False)
        self.test_f1 = tf.Variable(0.0,dtype=tf.float32, trainable=False)
        self.dev_f1 = tf.Variable(0.0,dtype=tf.float32, trainable=False)

    def _build_model(self):
        with tf.variable_scope("embeddings_op"):
            # word table
            word_table = Embedding(self.word_size, self.cfg.word_dim, self.cfg.wordvec, self.cfg.word_weight,
                                   self.cfg.tune_emb, self.cfg.at, self.cfg.norm_emb, self.cfg.word_project,
                                   scope="word_table")
            word_emb = word_table(self.words)
            # # char table
            # char_table = Embedding(self.char_size, self.cfg.char_dim, None, self.cfg.char_weight, True, self.cfg.at,
            #                        self.cfg.norm_emb, False, scope="char_table")
            # char_emb = char_table(self.chars)

        with tf.variable_scope("computation_graph"):
            # create module
            emb_dropout = tf.layers.Dropout(rate=self.cfg.emb_drop_rate)
            # char_tdnn_hw = CharTDNNHW(self.cfg.char_kernels, self.cfg.char_kernel_features, self.cfg.char_dim,
            #                           self.cfg.highway_layers, padding="VALID", activation=tf.tanh, use_bias=True,
            #                           hw_activation=tf.tanh, reuse=tf.AUTO_REUSE, scope="char_tdnn_hw")
            bi_rnn = BiRNN(self.cfg.num_units, drop_rate=self.cfg.rnn_drop_rate, concat=self.cfg.concat_rnn,
                           activation=tf.tanh, reuse=tf.AUTO_REUSE, scope="bi_rnn")
            dense = tf.layers.Dense(units=self.label_size, use_bias=True, _reuse=tf.AUTO_REUSE, name="project")
            crf_layer = CRF(self.label_size, reuse=tf.AUTO_REUSE, scope="crf")

            # compute outputs
            def compute_logits(w_emb):
                # char_cnn = char_tdnn_hw(c_emb)
                emb = emb_dropout(w_emb, training=self.is_train)
                rnn_outputs = bi_rnn(emb, self.seq_len, training=self.is_train)
                logits = dense(rnn_outputs)
                transition, mean_loss = crf_layer(logits, self.labels, self.seq_len)
                return logits, transition, mean_loss

            self.logits, self.transition, self.loss = compute_logits(word_emb)
            if self.cfg.at:
                perturb_word_emb = self.add_perturbation(word_emb, self.loss, epsilon=self.cfg.epsilon)
                # perturb_char_emb = self.add_perturbation(char_emb, self.loss, epsilon=self.cfg.epsilon)
                *_, adv_loss = compute_logits(perturb_word_emb)
                self.loss += adv_loss
        
        optimizer = tf.train.AdamOptimizer(learning_rate=self.lr)
        if self.cfg.grad_clip is not None and self.cfg.grad_clip > 0:
            grads, vs = zip(*optimizer.compute_gradients(self.loss))
            grads, _ = tf.clip_by_global_norm(grads, self.cfg.grad_clip)
            self.train_op = optimizer.apply_gradients(zip(grads, vs))
        else:
            self.train_op = optimizer.minimize(self.loss)

    def _predict_op(self, data):
        feed_dict = self._get_feed_dict(data)
        logits, transition, seq_len = self.sess.run([self.logits, self.transition, self.seq_len], feed_dict=feed_dict)
        return self.viterbi_decode(logits, transition, seq_len)

    def train(self, dataset):
        self.logger.info("Start training...")
        best_f1, no_imprv_epoch, init_lr, lr, cur_step = -np.inf, 0, self.cfg.lr, self.cfg.lr, 0
        mean_loss_scalar = tf.summary.scalar("mean Loss", self.mean_loss_summary)
        loss_scalar = tf.summary.scalar("NER Loss", self.loss_summary)
        # test_f1_scalar = tf.summary.scalar("test_f1", self.test_f1)
        dev_f1_scalar = tf.summary.scalar("dev_f1", self.dev_f1)
        loss_summary_op =  tf.summary.merge([loss_scalar,mean_loss_scalar,dev_f1_scalar])
        # self.summary = tf.summary.merge_all()
        self.train_writer = tf.summary.FileWriter(self.cfg.summary_path + "train", self.sess.graph)
        self.test_writer = tf.summary.FileWriter(self.cfg.summary_path + "test")
        loss = []
        for epoch in range(1, self.cfg.epochs + 1):
            
            self.logger.info('Epoch {}/{}:'.format(epoch, self.cfg.epochs))
            prog = Progbar(target=dataset.get_num_batches())
            
            for i, data in enumerate(dataset.get_data_batches()):
                cur_step += 1
                feed_dict = self._get_feed_dict(data, is_train=True, lr=lr)
                _, train_loss = self.sess.run([self.train_op, self.loss], feed_dict=feed_dict)
                loss.append(train_loss)
                # if cur_step % self.cfg.log_step == 0:
                #     self.mean_loss = self.mean_loss/self.cfg.log_step
                    
                #     self.mean_loss = 0           

                prog.update(i + 1, [("Global Step", int(cur_step)), ("Train Loss", train_loss)])
                # if cur_step % self.cfg.log_step ==0:
                #     loss_scalar_run = self.sess.run(loss_scalar)
                #     self.train_writer.add_summary(loss_scalar_run, cur_step)                    
                #     self.sess.run(tf.assign(self.mean_loss_summary, np.mean(loss)))
                #     self.sess.run(tf.assign(self.loss_summary, train_loss))
                #     mean_loss_scalar_run = self.sess.run(mean_loss_scalar)
                #     self.train_writer.add_summary(mean_loss_scalar_run, cur_step)
                #     loss = [] 
            # learning rate decay
            if self.cfg.use_lr_decay:
                if self.cfg.decay_step:
                    lr = max(init_lr / (1.0 + self.cfg.lr_decay * epoch / self.cfg.decay_step), self.cfg.minimal_lr)
            # evaluate
            if not self.cfg.dev_for_train:
                self.evaluate(dataset.get_data_batches("dev"), "dev", self._predict_op, self.rev_word_dict,
                              self.rev_label_dict)
            score,eval_lines,y_pred,y_true = self.evaluate(dataset.get_data_batches("test"), "test", self._predict_op, self.rev_word_dict,
                                  self.rev_label_dict)
            self.sess.run(tf.assign(self.mean_loss_summary, np.mean(loss)))
            self.sess.run(tf.assign(self.loss_summary, train_loss))
            self.sess.run(tf.assign(self.dev_f1, score["FB1"]))
            loss = []
            # dev_f1_scalar_run = self.sess.run(dev_f1_scalar)
            summary = self.sess.run(loss_summary_op)
            # self.train_writer.add_summary(dev_f1_scalar_run, epoch)         
            self.train_writer.add_summary(summary, epoch)
            if score["FB1"] > best_f1:
                best_f1, no_imprv_epoch = score["FB1"], 0
                self.save_session(epoch)
                # save_cr_and_cm(self.rev_label_dict, y_pred, y_true, cr_save_path=os.path.join(self.cfg.checkpoint_path,'cm.csv'), cm_save_path=os.path.join(self.cfg.checkpoint_path,'cm.png'))
                self.logger.info(' -- new BEST score on test dataset: {:04.2f}'.format(best_f1))
                for line in eval_lines:
                    self.logger.info(line)
                with open(os.path.join(self.cfg.checkpoint_path,'best_dev.txt'),'w+',encoding='utf-8') as f:
                    for line in eval_lines:
                        f.write(line)
                        f.write('\n')
            else:
                no_imprv_epoch += 1
                if self.cfg.no_imprv_tolerance is not None and no_imprv_epoch >= self.cfg.no_imprv_tolerance:
                    self.logger.info('early stop at {}th epoch without improvement'.format(epoch))
                    self.logger.info('best score on test set: {}'.format(best_f1))
                    break

    def evaluate_data(self, dataset, name):
        self.evaluate(dataset, name, self._predict_op, self.rev_word_dict, self.rev_label_dict)


class BaseModel_for_BERT(Base):
    """Basement model: Char CNN + LSTM encoder + Chain CRF decoder module"""
    def __init__(self, config):
        super(BaseModel_for_BERT, self).__init__(config)
        self._init_configs()        
        
        with tf.Graph().as_default():           
            self._add_placeholders()
            self._build_model()
            self.logger.info("total params: {}".format(self.count_params()))
            print_config(config,self.logger,Base=True)
            with open(os.path.join(self.cfg.checkpoint_path,'speed.txt'),"a+",encoding='utf-8') as inp:
                inp.write("total params: {}/n".format(self.count_params("computation_graph")))
            self._initialize_session()
            self._tensorboard()

    def _init_configs(self):        
        tokenization.validate_case_matches_checkpoint(self.cfg.word_lowercase,
                                                  self.cfg.bert_model_path)
        self.tokenizer = tokenization.FullTokenizer(
                vocab_file=self.cfg.vocab_file, do_lower_case=self.cfg.word_lowercase)
        
        self.bert_config = BertConfig.from_json_file(self.cfg.bert_config) # 配置文件地址。
        self.lable2id = self.cfg.lable2id
        self.num_labels =len( self.cfg.lable2id)
        self.rev_word_dict = self.tokenizer.inv_vocab
        self.rev_label_dict = dict([(idx, label) for label, idx in self.lable2id.items()])
       

 
   
    def _get_feed_dict(self, dataset, is_train=False, lr=None):
        feed_dict = {self.is_train: is_train}
        if lr is not None:
            feed_dict[self.lr] = lr        

        feed_dict[self.input_ids] = dataset["input_ids"]
        feed_dict[self.lengths] = dataset["seq_lengths"]
        feed_dict[self.input_mask] = dataset["input_mask"]
        feed_dict[self.segment_ids] = dataset["segment_ids"]
        if "label_id" in dataset:
            feed_dict[self.labels] = dataset["label_id"]
        
        return feed_dict



    def _tensorboard(self):        
        tf.summary.scalar('loss/loss', self.loss)
        if self.cfg.at:
            tf.summary.scalar('loss/adv_tgt_loss', self.adv_loss)
        self.summary_op = tf.summary.merge_all()
        self.dev_F1_scalar = tf.summary.scalar('dev_F1/dev_f1', self.dev_f1)
        self.test_F1_scalar = tf.summary.scalar('dev_F1/test_f1', self.test_f1)
        self.F1_summary_op = tf.summary.merge([self.dev_F1_scalar,self.test_F1_scalar])
        self.train_writer = tf.summary.FileWriter(self.cfg.summary_path + "train", self.sess.graph)
       
    def bert_embedding(self,input_ids,input_mask,segment_ids):
        # load bert embedding        
        model = modeling.BertModel(
                config=self.bert_config,
                is_training=False,
                input_ids=input_ids,
                input_mask=input_mask,
                token_type_ids=segment_ids,
                use_one_hot_embeddings=False,
                )
        self.embedding = model.get_sequence_output()
        self.embedding_summary_op = tf.summary.histogram('bert_embedding/embedding',self.embedding)
        return self.embedding
   
    def _add_placeholders(self):
        self.input_ids = tf.placeholder(dtype=tf.int32, shape=[None, None], name="src_input_ids")
        self.input_mask = tf.placeholder(dtype=tf.int32, shape=[None, None], name="src_input_mask")
        self.segment_ids = tf.placeholder(dtype=tf.int32, shape=[None, None], name="src_segment_ids")
        self.labels = tf.placeholder(tf.int32, shape=[None, None], name="src_labels") #任务1的label     

        # domain labels
        self.domain_labels = tf.placeholder(tf.int32, shape=[None, 2], name="domain_labels")        
        # hyper-parameters        
        self.is_train = tf.placeholder(tf.bool, shape=[], name="is_train")
        self.test_f1 = tf.Variable(0.0,dtype=tf.float32, trainable=False)
        self.dev_f1 = tf.Variable(0.0,dtype=tf.float32, trainable=False)
        self.train_f1 = tf.Variable(0.0,dtype=tf.float32, trainable=False)
      
        self.lr = tf.placeholder(tf.float32, name="source_learning_rate")
        self.loss_summary = tf.Variable(0.0, dtype=tf.float32,trainable=False)
        self.mean_loss_summary = tf.Variable(0.0,dtype=tf.float32, trainable=False)

        self.keep_prob = tf.placeholder(tf.float32, name='keep_prob')  # , name='is_training'
        used = tf.sign(tf.abs(self.input_ids))
        length = tf.reduce_sum(used, reduction_indices=1)      
        self.lengths = tf.cast(length, tf.int32)       
        self.batch_size = tf.shape(self.input_ids)[0]
        self.num_steps = tf.shape(self.input_ids)[-1]       

    def _build_model(self):
        
        word_emb = self.bert_embedding(self.input_ids,self.input_mask,self.segment_ids)

        with tf.variable_scope("computation_graph"):
            # create module
            emb_dropout = tf.layers.Dropout(rate=self.cfg.emb_drop_rate)
            # char_tdnn_hw = CharTDNNHW(self.cfg.char_kernels, self.cfg.char_kernel_features, self.cfg.char_dim,
            #                           self.cfg.highway_layers, padding="VALID", activation=tf.tanh, use_bias=True,
            #                           hw_activation=tf.tanh, reuse=tf.AUTO_REUSE, scope="char_tdnn_hw")
            bi_rnn = BiRNN(self.cfg.num_units, drop_rate=self.cfg.rnn_drop_rate, concat=self.cfg.concat_rnn,
                           activation=tf.tanh, reuse=tf.AUTO_REUSE, scope="bi_rnn")
            dense = tf.layers.Dense(units=self.num_labels, use_bias=True, _reuse=tf.AUTO_REUSE, name="project")
            crf_layer = CRF(self.num_labels, reuse=tf.AUTO_REUSE, scope="crf")

            # compute outputs
            def compute_logits(output_layer):
                # char_cnn = char_tdnn_hw(c_emb)
                emb = emb_dropout(output_layer, training=self.is_train)
                rnn_outputs = bi_rnn(emb, self.lengths, training=self.is_train)
                logits = dense(rnn_outputs)
                transition, mean_loss = crf_layer(logits, self.labels, self.lengths)
                return logits, transition, mean_loss

            self.logits, self.transition, self.loss = compute_logits(word_emb)
            self.src_rnn_outs = tf.summary.histogram('computation_graph/logits', self.logits)
            if self.cfg.at:
                perturb_word_emb = self.add_perturbation(word_emb, self.loss, epsilon=self.cfg.epsilon)
                # perturb_char_emb = self.add_perturbation(char_emb, self.loss, epsilon=self.cfg.epsilon)
                *_, self.adv_loss = compute_logits(perturb_word_emb)
                self.loss += self.adv_loss
        

        tvars = tf.trainable_variables()
        initialized_variable_names = {}
        scaffold_fn = None
        init_checkpoint = self.cfg.init_checkpoint
        if init_checkpoint:
            (assignment_map, initialized_variable_names
             ) = modeling.get_assignment_map_from_checkpoint(tvars, init_checkpoint)
 
            tf.train.init_from_checkpoint(init_checkpoint, assignment_map)

        tf.logging.info("**** Trainable Variables ****")
        non_bert_vars = []
        for var in tvars:
            init_string = ""
            if var.name in initialized_variable_names:
                init_string = ", *INIT_FROM_CKPT*"
                tf.logging.info("  name = %s, shape = %s%s", var.name, var.shape,
                            init_string)
            else:
                non_bert_vars.append(var)

        optimizer = tf.train.AdamOptimizer(learning_rate=self.lr)   
        
        
        if self.cfg.grad_clip is not None and self.cfg.grad_clip > 0:
            grads, vs = zip(*optimizer.compute_gradients(self.loss, non_bert_vars))
            grads, _ = tf.clip_by_global_norm(grads, self.cfg.grad_clip)
            self.train_op = optimizer.apply_gradients(zip(grads, vs))
        else:
            self.train_op = optimizer.minimize(self.loss)

    def _predict_op(self, data):
        feed_dict = self._get_feed_dict(data)
        logits, transition, seq_len = self.sess.run([self.logits, self.transition, self.lengths], feed_dict=feed_dict)
        return self.viterbi_decode(logits, transition, seq_len)

    def train(self,dataset):

        self.logger.info("Start training...")
        best_f1, no_imprv_epoch, init_lr, lr, cur_step = -np.inf, 0, self.cfg.lr, self.cfg.lr, 0
        
        loss = []
        for epoch in range(1, self.cfg.epochs + 1):
            
            self.logger.info('Epoch {}/{}:'.format(epoch, self.cfg.epochs))
            prog = Progbar(target=dataset.get_num_batches())
            
            
            for i, data in enumerate(dataset.get_data_batches()):
                cur_step += 1

                feed_dict = self._get_feed_dict(data, is_train=True, lr=lr)
                _, train_loss,summary = self.sess.run([self.train_op, self.loss,self.summary_op], feed_dict=feed_dict)
                loss.append(train_loss)
                self.train_writer.add_summary(summary, cur_step)
                self.train_writer.flush()    

                prog.update(i + 1, [("Global Step", int(cur_step)), ("Train Loss", train_loss)])
           
            # learning rate decay
            if self.cfg.use_lr_decay:
                if self.cfg.decay_step:
                    lr = max(init_lr / (1.0 + self.cfg.lr_decay * epoch / self.cfg.decay_step), self.cfg.minimal_lr)
            # evaluate
            if not self.cfg.dev_for_train:
                self.evaluate(dataset.get_data_batches("dev"), "dev", self._predict_op, self.rev_word_dict,
                              self.rev_label_dict)
            score,eval_lines,y_pred,y_true = self.evaluate(dataset.get_data_batches("test"), "test", self._predict_op, self.rev_word_dict,
                                  self.rev_label_dict)
            
            self.sess.run(tf.assign(self.dev_f1, score["FB1"]))
            F1_summary = self.sess.run(self.F1_summary_op)
            self.train_writer.add_summary(F1_summary, epoch)
            self.train_writer.flush()        
            
            if score["FB1"] > best_f1:
                best_f1, no_imprv_epoch = score["FB1"], 0
                self.save_session(epoch)
                # save_cr_and_cm(self.rev_label_dict, y_true, y_pred , language=self.cfg.language,cr_save_path=os.path.join(self.cfg.checkpoint_path,'cm.csv'), cm_save_path=os.path.join(self.cfg.checkpoint_path,'cm.png'))
                self.logger.info(' -- new BEST score on test dataset: {:04.2f}'.format(best_f1))
                for line in eval_lines:
                    self.logger.info(line)
                with open(os.path.join(self.cfg.checkpoint_path,'best_dev.txt'),'w+',encoding='utf-8') as f:
                    for line in eval_lines:
                        f.write(line)
                        f.write('\n')
            else:
                no_imprv_epoch += 1
                if self.cfg.no_imprv_tolerance is not None and no_imprv_epoch >= self.cfg.no_imprv_tolerance:
                    self.logger.info('early stop at {}th epoch without improvement'.format(epoch))
                    self.logger.info('best score on test set: {}'.format(best_f1))
                    break

    def evaluate_data(self, dataset, name):
        self.evaluate(dataset, name, self._predict_op, self.rev_word_dict, self.rev_label_dict)
