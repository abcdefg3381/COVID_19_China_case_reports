import time
import tensorflow as tf
import numpy as np
from models.shares import Base,fc_layer, flip_gradient, CharTDNNHW, BiRNN, CRF, self_attn, focal_loss, Embedding,save_cr_and_cm
from utils.logger import Progbar
import os
import models.tensorflow_utils as tf_utils
from tensorflow.contrib.layers import flatten


class DATNetFModel(Base):
    """Full Transfer and DATNet-F modules"""
    def __init__(self, config):
        super(DATNetFModel, self).__init__(config)
        self._init_configs()
        with tf.Graph().as_default():
            self._add_placeholders()
            self._build_model()
            self.logger.info("total params: {}".format(self.count_params()))            
            self._initialize_session()
            self._tensorboard()


    def _init_configs(self):
        s_vocab = self.load_dataset(self.cfg.src_vocab)
        t_vocab = self.load_dataset(self.cfg.tgt_vocab)
        self.sw_dict, self.sl_dict = s_vocab["word_dict"], s_vocab["label_dict"]
        self.tw_dict, self.tl_dict = t_vocab["word_dict"], t_vocab["label_dict"]
        del s_vocab, t_vocab
        self.sw_size,  self.sl_size = len(self.sw_dict),  len(self.sl_dict)
        self.tw_size,  self.tl_size = len(self.tw_dict),  len(self.tl_dict)
        self.rev_sw_dict = dict([(idx, word) for word, idx in self.sw_dict.items()])       
        self.rev_sl_dict = dict([(idx, label) for label, idx in self.sl_dict.items()])
        self.rev_tw_dict = dict([(idx, word) for word, idx in self.tw_dict.items()])       
        self.rev_tl_dict = dict([(idx, label) for label, idx in self.tl_dict.items()]) 
        self.dis_c = [64,128,256]       
        self.wd_param = 0.1
        self.gp_param = 10
        self.D_train_num =10
        self.l2_param = 1e-5
    def _get_feed_dict(self, src_data, tgt_data, domain_labels, is_train=False, src_lr=None, tgt_lr=None):
        feed_dict = {self.is_train: is_train}
        if src_lr is not None:
            feed_dict[self.src_lr] = src_lr
        if tgt_lr is not None:
            feed_dict[self.tgt_lr] = tgt_lr
        if src_data is not None:
            feed_dict[self.src_words] = src_data["words"]
            feed_dict[self.src_seq_len] = src_data["seq_len"]
            if "labels" in src_data:
                feed_dict[self.src_labels] = src_data["labels"]
        if tgt_data is not None:
            feed_dict[self.tgt_words] = tgt_data["words"]
            feed_dict[self.tgt_seq_len] = tgt_data["seq_len"]
            if "labels" in tgt_data:
                feed_dict[self.tgt_labels] = tgt_data["labels"]
        if domain_labels is not None:
            feed_dict[self.domain_labels] = domain_labels
        return feed_dict

    def _add_placeholders(self):
        # source placeholders

        self.src_words = tf.placeholder(tf.int32, shape=[None, 200], name="source_words")
        self.src_seq_len = tf.placeholder(tf.int32, shape=[None], name="source_seq_len")        
        self.src_labels = tf.placeholder(tf.int32, shape=[None, None], name="source_labels")
        # target placeholders
        self.tgt_words = tf.placeholder(tf.int32, shape=[None, 200], name="target_words")
        self.tgt_seq_len = tf.placeholder(tf.int32, shape=[None], name="target_seq_len")        
        self.tgt_labels = tf.placeholder(tf.int32, shape=[None, None], name="target_labels")
        # domain labels
        self.domain_labels = tf.placeholder(tf.int32, shape=[None, 2], name="domain_labels")
        # hyper-parameters
        self.is_train = tf.placeholder(tf.bool, shape=[], name="is_train")
        self.src_lr = tf.placeholder(tf.float32, name="source_learning_rate")
        self.tgt_lr = tf.placeholder(tf.float32, name="target_learning_rate")
        self.loss_summary = tf.Variable(0.0, dtype=tf.float32,trainable=False)
        self.mean_loss_summary = tf.Variable(0.0,dtype=tf.float32, trainable=False)
        self.tgt_f1 = tf.Variable(0.0,dtype=tf.float32, trainable=False)
        self.src_f1 = tf.Variable(0.0,dtype=tf.float32, trainable=False)
        self.max_seq_len = self.cfg.max_seq_len


    def _tensorboard(self):
        tf.summary.scalar('loss/negative_wgan_d_loss', -self.wd_loss)
        tf.summary.scalar('loss/wd_loss', self.wd_loss)
        tf.summary.scalar('loss/gp_loss', self.gp_loss)
        tf.summary.scalar('loss/negative_src_loss', -self.src_loss)  # negative critic loss
        tf.summary.scalar('loss/src_loss', self.src_loss)  # negative critic loss
        tf.summary.scalar('loss/tgt_loss', self.tgt_loss)
        tf.summary.scalar('loss/l2_loss', self.l2_loss)
        # tf.summary.scalar('loss/src_dis_loss', self.src_dis_loss)
        tf.summary.scalar('loss/d_loss', self.d_loss)   
        tf.summary.scalar('loss/src_loss_orgin', self.src_loss_orgin)  # negative critic loss
        tf.summary.scalar('loss/tgt_loss_orgin', self.tgt_loss_orgin)
        # tf.summary.scalar('loss/mid', self.mid)
        # tf.summary.scalar('loss/d_loss', self.d_loss)
        self.summary_op = tf.summary.merge_all()
        self.tgt_F1_scalar = tf.summary.scalar('dev_F1/tgt_f1', self.tgt_f1)
        self.src_F1_scalar = tf.summary.scalar('dev_F1/src_f1', self.src_f1)
        self.F1_summary_op = tf.summary.merge([self.tgt_F1_scalar,self.src_F1_scalar])

        self.train_writer = tf.summary.FileWriter(self.cfg.summary_path + "train", self.sess.graph)
        # self.test_writer = tf.summary.FileWriter(self.cfg.summary_path + "dev")

    def basicDiscriminator(self, data, name='critic', is_reuse=False):
        with tf.variable_scope(name) as scope:
            if is_reuse is True:
                tf.get_variable_scope().reuse_variables()
            tf_utils.print_activations(data)

            src_image = tf.reshape(data, [-1, 200, 200, 2])

            # from (N, 200, 200, 2) to (N, 200, 200, 64)
            h0_conv = tf_utils.conv2d(src_image, self.dis_c[0], k_h=5, k_w=5, name='h0_conv2d')
            h0_lrelu = tf_utils.lrelu(h0_conv, name='h0_lrelu')

            # from (N, 16, 16, 64) to (N, 8, 8, 128)
            h1_conv = tf_utils.conv2d(h0_lrelu, self.dis_c[1], k_h=5, k_w=5, name='h1_conv2d')
            h1_lrelu = tf_utils.lrelu(h1_conv, name='h1_lrelu')

            # from (N, 8, 8, 128) to (N, 4, 4, 256)
            h2_conv = tf_utils.conv2d(h1_lrelu, self.dis_c[2], k_h=5, k_w=5, name='h2_conv2d')
            h2_lrelu = tf_utils.lrelu(h2_conv, name='h2_lrelu')

            # from (N, 4, 4, 256) to (N, 4096) and to (N, 1)
            h2_flatten = flatten(h2_lrelu)
            h3_linear = tf_utils.linear(h2_flatten, 1, name='h3_linear')

            return tf.nn.sigmoid(h3_linear), h3_linear
    def _build_model(self):
        with tf.variable_scope("embeddings_op"):
            # word table
            if self.cfg.share_word:
                word_table = Embedding(self.sw_size, self.cfg.src_word_dim, self.cfg.src_wordvec,
                                       self.cfg.src_word_weight, self.cfg.tune_emb, self.cfg.at, self.cfg.norm_emb,
                                       self.cfg.word_project, scope="word_table")
                src_word_emb = word_table(self.src_words)
                tgt_word_emb = word_table(self.tgt_words)
            else:
                src_word_table = Embedding(self.sw_size, self.cfg.src_word_dim, self.cfg.src_wordvec,
                                           self.cfg.src_word_weight, self.cfg.tune_emb, self.cfg.at, self.cfg.norm_emb,
                                           self.cfg.word_project, scope="source_word_table")
                src_word_emb = src_word_table(self.src_words)
                tgt_word_table = Embedding(self.tw_size, self.cfg.tgt_word_dim, self.cfg.tgt_wordvec,
                                           self.cfg.tgt_word_weight, self.cfg.tune_emb, self.cfg.at, self.cfg.norm_emb,
                                           self.cfg.word_project, scope="target_word_table")
                tgt_word_emb = tgt_word_table(self.tgt_words)
            # char table (default char is shared)

        with tf.variable_scope("computation_graph"):
            # build module
            emb_dropout = tf.layers.Dropout(rate=self.cfg.emb_drop_rate)
            bi_rnn = BiRNN(self.cfg.num_units, drop_rate=self.cfg.rnn_drop_rate, concat=self.cfg.concat_rnn,
                           activation=tf.tanh, reuse=tf.AUTO_REUSE, scope="bi_rnn")
            # create dense layer
            if self.cfg.share_dense:
                src_dense = tf.layers.Dense(self.sl_size, use_bias=True, _reuse=tf.AUTO_REUSE, name="project")
                tgt_dense = tf.layers.Dense(self.tl_size, use_bias=True, _reuse=tf.AUTO_REUSE, name="project")
            else:
                src_dense = tf.layers.Dense(self.sl_size, use_bias=True, _reuse=tf.AUTO_REUSE, name="src_project")
                tgt_dense = tf.layers.Dense(self.tl_size, use_bias=True, _reuse=tf.AUTO_REUSE, name="tgt_project")
            # create CRF layer
            if self.cfg.share_label:
                src_crf_layer = CRF(self.sl_size, reuse=tf.AUTO_REUSE, scope="crf_layer")
                tgt_crf_layer = CRF(self.sl_size, reuse=tf.AUTO_REUSE, scope="crf_layer")
            else:
                src_crf_layer = CRF(self.sl_size, reuse=tf.AUTO_REUSE, scope="src_crf_layer")
                tgt_crf_layer = CRF(self.tl_size, reuse=tf.AUTO_REUSE, scope="tgt_crf_layer")

            # compute outputs
            def discriminator(feature):
                feat = flip_gradient(feature, lw=self.cfg.grad_rev_rate)
                outputs = self_attn(feat, reuse=tf.AUTO_REUSE, name="self_attention")
                logits = tf.layers.dense(outputs, units=2, use_bias=True, name="disc_project", reuse=tf.AUTO_REUSE)
                if self.cfg.discriminator == 2:  # GRAD
                    loss = focal_loss(logits, self.domain_labels, alpha=self.cfg.alpha, gamma=self.cfg.gamma)
                    loss = tf.reduce_mean(loss)
                else:  # normal discriminator
                    loss = tf.nn.softmax_cross_entropy_with_logits_v2(logits=logits, labels=self.domain_labels)
                    loss = tf.reduce_mean(loss)
                return loss

            def fc_layer(input_tensor, input_dim, output_dim, layer_name, act=tf.nn.relu, input_type='dense'):
                with tf.name_scope(layer_name):
                    weight = tf.Variable(tf.truncated_normal([input_dim, output_dim], stddev=1. / tf.sqrt(input_dim / 2.)), name='weight')
                    bias = tf.Variable(tf.constant(0.1, shape=[output_dim]), name='bias')
                    if input_type == 'sparse':
                        activations = act(tf.sparse_tensor_dense_matmul(input_tensor, weight) + bias)
                    else:
                        activations = act(tf.matmul(input_tensor, weight) + bias)
                    return activations
            
            def compute_src_logits(word_emb):
                emb = emb_dropout(word_emb, training=self.is_train)
                rnn_outs = bi_rnn(emb,seq_len=None,training=self.is_train)
                logits = src_dense(rnn_outs)
                transition, mean_loss = src_crf_layer(logits, self.src_labels, self.src_seq_len)
                return rnn_outs, logits, transition, mean_loss

            def compute_tgt_logits(word_emb):
                emb = emb_dropout( word_emb, training=self.is_train)
                rnn_outs = bi_rnn(emb,seq_len=None,training=self.is_train)
                logits = tgt_dense(rnn_outs)
                transition, mean_loss = tgt_crf_layer(logits, self.tgt_labels, self.tgt_seq_len)
                return rnn_outs, logits, transition, mean_loss

            # train source
            with tf.name_scope('generator'):
                src_rnn_outs, self.src_logits, self.src_transition, self.src_loss_orgin = compute_src_logits(src_word_emb)
                if self.cfg.at:  # adversarial training
                    perturb_src_word_emb = self.add_perturbation(src_word_emb, self.src_loss_orgin, epsilon=self.cfg.epsilon)
                    *_, self.adv_src_loss = compute_src_logits(perturb_src_word_emb)
                    self.src_loss_orgin = self.src_loss_orgin + self.adv_src_loss
                if self.cfg.discriminator != 0:  # if 0 means no discriminator is applied
                    self.src_dis_loss = discriminator(src_rnn_outs)
                    self.src_loss_orgin = self.src_loss_orgin + self.src_dis_loss
                
                tgt_rnn_outs, self.tgt_logits, self.tgt_transition, self.tgt_loss_orgin = compute_tgt_logits(tgt_word_emb)
                if self.cfg.at:
                    perturb_tgt_word_emb = self.add_perturbation(tgt_word_emb, self.tgt_loss_orgin, epsilon=self.cfg.epsilon)
                    *_, self.adv_tgt_loss = compute_tgt_logits(perturb_tgt_word_emb)
                    self.tgt_loss_orgin = self.tgt_loss_orgin + self.adv_tgt_loss
                if self.cfg.discriminator != 0:
                    self.tgt_dis_loss = discriminator(tgt_rnn_outs)
                    self.tgt_loss_orgin = self.tgt_loss_orgin + self.tgt_dis_loss
            
            src_rnn_outs_flatten = flatten(src_rnn_outs)
            tgt_rnn_outs_flatten = flatten(tgt_rnn_outs)

            _, d_logit_src = self.basicDiscriminator(src_rnn_outs)
            _, d_logit_tgt = self.basicDiscriminator(tgt_rnn_outs, is_reuse=True)
            alpha = tf.random_uniform(shape=[self.cfg.batch_size,1], minval=0., maxval=1.)

            differences = src_rnn_outs_flatten - tgt_rnn_outs_flatten   
            interpolates = tgt_rnn_outs_flatten + (alpha*differences)

            self.gradients = tf.gradients(self.basicDiscriminator(interpolates,is_reuse=True), [interpolates])[0]
            # self.mid = tf.reduce_sum(tf.square(self.gradients), reduction_indices=[1])
            self.slopes = tf.sqrt(tf.reduce_sum(tf.square(self.gradients), reduction_indices=[1]))            
            
            self.wd_loss = tf.reduce_mean(d_logit_src) - tf.reduce_mean(d_logit_tgt) 
            self.gp_loss = tf.reduce_mean((self.slopes-1.)**2) 
            self.d_loss = -self.wd_loss + self.gp_param * self.gp_loss

            all_variables = tf.trainable_variables()
            self.l2_loss = self.l2_param * tf.add_n([tf.nn.l2_loss(v) for v in all_variables if 'bias' not in v.name])
            #1.0
            self.src_loss = self.src_loss_orgin  + self.wd_param * self.wd_loss 
            self.tgt_loss = self.tgt_loss_orgin  + self.wd_param * self.wd_loss 
            #2.0
            # self.src_loss = self.src_loss_orgin  + self.d_loss
            # self.tgt_loss = self.tgt_loss_orgin  + self.d_loss
            #3.0
            # self.src_loss = self.src_loss_orgin  - self.wd_param * self.wd_loss + self.gp_param * self.gp_loss
            # self.tgt_loss = self.tgt_loss_orgin  - self.wd_param * self.wd_loss + self.gp_param * self.gp_loss
            #4.0
            # self.src_loss = self.src_loss_orgin  +  self.wd_loss + self.gp_param * self.gp_loss             
            # self.tgt_loss = self.tgt_loss_orgin  +  self.wd_loss + self.gp_param * self.gp_loss 
        theta_D = [v for v in tf.global_variables() if 'critic' in v.name]
        theta_G = [v for v in tf.global_variables() if 'critic' not in v.name]
        self.wd_d_op = tf.train.AdamOptimizer(self.cfg.lr).minimize(self.d_loss, var_list=theta_D)

        src_optimizer = tf.train.AdamOptimizer(learning_rate=self.src_lr)
        if self.cfg.grad_clip is not None and self.cfg.grad_clip > 0:
            grads, vs = zip(*src_optimizer.compute_gradients(self.src_loss))
            grads, _ = tf.clip_by_global_norm(grads, self.cfg.grad_clip)
            self.src_train_op = src_optimizer.apply_gradients(zip(grads, vs))
        else:
            self.src_train_op = src_optimizer.minimize(self.src_loss)

        tgt_optimizer = tf.train.AdamOptimizer(learning_rate=self.tgt_lr)
        if self.cfg.grad_clip is not None and self.cfg.grad_clip > 0:
            grads, vs = zip(*tgt_optimizer.compute_gradients(self.tgt_loss))
            grads, _ = tf.clip_by_global_norm(grads, self.cfg.grad_clip)
            self.tgt_train_op = tgt_optimizer.apply_gradients(zip(grads, vs))
        else:
            self.tgt_train_op = tgt_optimizer.minimize(self.tgt_loss)
        
        # src_optimizer = tf.train.AdamOptimizer(learning_rate=self.src_lr)
        # self.src_train_op = src_optimizer.minimize(self.src_loss,var_list=theta_G)

        # tgt_optimizer = tf.train.AdamOptimizer(learning_rate=self.tgt_lr)
        # self.tgt_train_op = tgt_optimizer.minimize(self.tgt_loss,var_list=theta_G)

    def _src_predict_op(self, data):
        feed_dict = self._get_feed_dict(src_data=data, tgt_data=None, domain_labels=None)
        logits, transition, seq_len = self.sess.run([self.src_logits, self.src_transition, self.src_seq_len],
                                                    feed_dict=feed_dict)
        return self.viterbi_decode(logits, transition, seq_len)

    def _tgt_predict_op(self, data):
        feed_dict = self._get_feed_dict(src_data=None, tgt_data=data, domain_labels=None)
        logits, transition, seq_len = self.sess.run([self.tgt_logits, self.tgt_transition, self.tgt_seq_len],
                                                    feed_dict=feed_dict)
        return self.viterbi_decode(logits, transition, seq_len)

    def train(self, src_dataset, tgt_dataset):
        self.logger.info("Start training...")
        best_f1, no_imprv_epoch, src_lr, tgt_lr, cur_step = -np.inf, 0, self.cfg.lr, self.cfg.lr, 0
        total_speed = 0
        for epoch in range(1, self.cfg.epochs + 1):
            self.logger.info("Epoch {}/{}:".format(epoch, self.cfg.epochs))
            batches = self._arrange_batches(src_dataset, tgt_dataset, self.cfg.mix_rate, self.cfg.train_ratio)
            prog = Progbar(target=len(batches))
            prog.update(0, [("Global Step", int(cur_step)), ("Source Train Loss", 0.0), ("Target Train Loss", 0.0)])
            start = time.time()
            for i, batch_name in enumerate(batches):
                cur_step += 1
                src_data = src_dataset.get_next_train_batch()
                tgt_data = tgt_dataset.get_next_train_batch()
                for D_num in range(self.D_train_num):
                    # domain_labels = [[1, 0]] * data["batch_size"]
                    feed_dict = self._get_feed_dict(src_data=src_data, tgt_data=tgt_data, domain_labels=None,
                                                    is_train=True, src_lr=src_lr)
                    dis_run = [self.wd_d_op, self.wd_loss, self.gp_loss, self.d_loss]
                    _, wd_loss,gp_loss,d_loss = self.sess.run(dis_run, feed_dict=feed_dict)
                    # self.logger.info("D_train_num{} wd_loss:{} , gp_loss:{} , d_loss: {}:".format(D_num,wd_loss,gp_loss,d_loss))
                if batch_name == "src":
                    domain_labels = [[1, 0]] * src_data["batch_size"]
                    feed_dict = self._get_feed_dict(src_data=src_data, tgt_data=tgt_data, domain_labels=domain_labels,
                                                    is_train=True, src_lr=src_lr)
                    _, src_cost,tgt_cost,summary = self.sess.run([self.src_train_op, self.src_loss,self.tgt_loss,self.summary_op], feed_dict=feed_dict)
                    prog.update(i + 1, [("Global Step", int(cur_step)), ("Source Train Loss", src_cost)])
                    self.train_writer.add_summary(summary, cur_step)
                    self.train_writer.flush()
                else:  # "tgt"                    
                    domain_labels = [[0, 1]] * tgt_data["batch_size"]
                    feed_dict = self._get_feed_dict(src_data=src_data, tgt_data=tgt_data, domain_labels=domain_labels,
                                                    is_train=True, tgt_lr=tgt_lr)
                    _, tgt_cost,src_cost,summary = self.sess.run([self.tgt_train_op, self.tgt_loss,self.src_loss,self.summary_op], feed_dict=feed_dict)
                    prog.update(i + 1, [("Global Step", int(cur_step)), ("Target Train Loss", tgt_cost)])
                    self.train_writer.add_summary(summary, cur_step)
                    self.train_writer.flush()
            
            if self.cfg.use_lr_decay:  # learning rate decay
                src_lr = max(self.cfg.lr / (1.0 + self.cfg.lr_decay * epoch), self.cfg.minimal_lr)
                if epoch % self.cfg.decay_step == 0:
                    tgt_lr = max(self.cfg.lr / (1.0 + self.cfg.lr_decay * epoch / self.cfg.decay_step),
                                 self.cfg.minimal_lr)
            if not self.cfg.dev_for_train:
                self.evaluate(tgt_dataset.get_data_batches("dev"), "target_dev", self._tgt_predict_op,
                              rev_word_dict=self.rev_tw_dict, rev_label_dict=self.rev_tl_dict)
            end = time.time()
            speed = (end-start)/len(batches)
            total_speed += speed
            total_average_speed = total_speed/epoch
            with open(os.path.join(self.cfg.checkpoint_path,'speed.txt'),"a+",encoding='utf-8') as inp:
                inp.write("The {} epoch:\n".format(epoch))
                inp.write('model time is :{} ,speed is :{}s/step\n'.format(str(end-start),str(speed)))
                inp.write('total average speed is {}s/step \n'.format(str(total_speed/epoch)))
                self.logger.info('the {} epoch speed is {}s/step,total average seed is {}s/step'.format(epoch,speed,total_average_speed))
            
            
            
            score,eval_lines,y_pred,y_true = self.evaluate(tgt_dataset.get_data_batches("test"), "target_test", self._tgt_predict_op,
                                  rev_word_dict=self.rev_tw_dict, rev_label_dict=self.rev_tl_dict)
            src_score,src_eval_lines,src_y_pred,src_y_true = self.evaluate(src_dataset.get_data_batches("test"), "src_test", self._src_predict_op,
                                  rev_word_dict=self.rev_sw_dict, rev_label_dict=self.rev_sl_dict)
            self.sess.run(tf.assign(self.tgt_f1, score["FB1"]))
            self.sess.run(tf.assign(self.src_f1, src_score["FB1"]))          
            F1_summary = self.sess.run(self.F1_summary_op)
            self.train_writer.add_summary(F1_summary, epoch)
            self.train_writer.flush()
            if score["FB1"] > best_f1:
                best_f1, no_imprv_epoch = score["FB1"], 0
                self.save_session(epoch)
                save_cr_and_cm(self.rev_tl_dict, y_true, y_pred, language=self.cfg.tgt_language,cr_save_path=os.path.join(self.cfg.checkpoint_path,'cm.csv'), cm_save_path=os.path.join(self.cfg.checkpoint_path,'cm.png'))
                self.logger.info(' -- new BEST score on target test dataset: {:04.2f}'.format(best_f1))
                for line in eval_lines:
                    self.logger.info(line)
                with open(os.path.join(self.cfg.checkpoint_path,'best_dev.txt'),'w+',encoding='utf-8') as f:
                    for line in eval_lines:
                        f.write(line)
                        f.write('\n')
            else:
                no_imprv_epoch += 1
                if self.cfg.no_imprv_tolerance is not None and no_imprv_epoch >= self.cfg.no_imprv_tolerance:
                    self.logger.info('early stop at {}th epoch without improvement'.format(epoch))
                    self.logger.info('best score on target test set: {}'.format(best_f1))
                    break

    def evaluate_data(self, dataset, name, resource="target"):
        if resource == "target":
            self.evaluate(dataset, name, self._tgt_predict_op, self.rev_tw_dict, self.rev_tl_dict)
        else:
            self.evaluate(dataset, name, self._src_predict_op, self.rev_sw_dict, self.rev_sl_dict)
