import pandas as pd
import re

def prepro():
    data = pd.read_excel('新病例.xlsx')
    contents=list(data['文本里关于病例的描述性信息'])
    print('共'+len(contents)+'条病例')
    with open("datasets/raw/wzz/0222/1/test.txt","w",encoding='utf-8') as f:
        for content in contents:
            if isinstance(content,str):
                content=content.replace('\n','')
                for char in content:
                    f.write(char+'\t'+'O'+'\n')       
            else:
                print("病例文本输入不正确！")
                f.write('。'+'\n')
            f.write('\n')

def afterpro():
    labels=['QYL','ZZL','MDL','MDT','GLT','FBT','JZT','ZSI','QZT']

    with open("test_result.txt","r",encoding='utf-8') as f:
        data=f.read()
    contents=data.split('\n\n')
    print('共'+len(contents)+'条病例')

    all=[]
    for content in contents:
        lines=content.split('\n')
        newlines=[]
        for line in lines:
            chars=line.split()
            newlines.append(chars)
        all.append(newlines)           

    ress=[]
    for chars in all[:-1]:
        res=[]
        items={}
        i=0
        while i<len(chars):
            if 'B' in chars[i][2]:
                key=chars[i][2][2:]
                value=chars[i][0]
                i+=1
                while 'I' in chars[i][2]:
                    value+=chars[i][0]
                    i+=1
                if key in items:
                    items[key]=items[key]+','+value
                else:
                    items[key]=value
            else:
                i+=1

        for key in labels:
            if key in items:
                res.append(items[key])
            else:
                res.append("NA")
        ress.append(res)

    result=pd.DataFrame(ress,columns=labels)

    data = pd.read_excel('新病例.xlsx')
    cont=data['文本里关于病例的描述性信息'].values
    result.insert(0,'文本里关于病例的描述性信息',cont)

    result.to_excel('result.xlsx',encoding='utf-8')