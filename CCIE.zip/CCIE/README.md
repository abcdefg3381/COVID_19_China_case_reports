1. 安装环境：依赖包及版本见requirement.txt
2. 将输入文件“新病例.xlsx”放入datnet_final文件夹下  
###输入文件命名为“新病例.xlsx”，按照“新病例.xlsx”中的格式输入测试数据。
3. 运行代码：
cd datnet_final  ###进入到datnet_final文件夹下
python train_base_model_bert.py  ###执行train_base_model_bert.py
4. 查看输出结果：输出结果在datnet_final文件夹下的“result.xlsx ”文件中 
