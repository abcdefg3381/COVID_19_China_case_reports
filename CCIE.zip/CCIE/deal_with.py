# %%
data_type ='drug'
with open('datasets/raw/baseinfo/train.txt','r',encoding='utf-8') as inpf:
    words_list,labels_list = [], []
    words, labels = [], [] 
    flag = 0
    for line in inpf:
        flag += 1
        line = line.lstrip().rstrip()
        if len(line) == 0 or line.startswith("-DOCSTART-"):
            if len(words) != 0:
                words_list.append(words)
                labels_list.append(labels)
                words, labels = [], []
        else:
            
            if data_type=='drug':
                try:
                    word,label = line.split('\t')
                except :
                    print(flag)
                    continue
                if word is None or label is None:
                    continue                    
                words.append(word)
                labels.append(label)
            # thin_labels.append(thin_label)
